﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes
{
    public class Employee
    {
        public static Database database = new Database();
        public enum Job
        {
            Manager,
            Delivery,
            Arranger
        }

        public string ID { get; set; }
        public string Fullname { get; set; }
        public string Email { get; set; }
        public DateTime Birthdate { get; set; }
        public Job Working { get; set; }
        public TimeSpan TimeStartWorking { get; set; }
        public TimeSpan TimeEndWorking { get; set; }

        public static DataTable getEmployee()
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT * FROM employee";

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }
    }
}
