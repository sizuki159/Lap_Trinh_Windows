﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes
{
    public class Borrows
    {
        private static Database database = new Database();
        public enum Status_Borrow
        {
            Borrowing,
            Returned
        }
        public int BookID { get; set; }
        public string UserCode { get; set; }
        public Status_Borrow Status { get; set; }
        //private DateTime Borrow_Time { get; set; }
        //private DateTime Return_Time { get; set; }

        public bool isInsert()
        {
            database.openConnection();

            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "INSERT INTO borrows(book_id, user_code, status, borrow_time, return_time) VALUES(@bookID, @userCode, @status, @borrow_time, @return_time)";
            command.Parameters.Add("@bookID", SqlDbType.Int).Value = BookID;
            command.Parameters.Add("@userCode", SqlDbType.NVarChar).Value = UserCode;
            command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status.ToString();

            DateTime dtObj = DateTime.Now;
            command.Parameters.Add("@borrow_time", System.Data.SqlDbType.DateTime).Value = dtObj;
            command.Parameters.Add("@return_time", System.Data.SqlDbType.DateTime).Value = dtObj.AddDays(7);

            if (command.ExecuteNonQuery() == 1)
            {
                database.closeConnection();
                return true;
            }
            database.closeConnection();
            return false;
        }

        public static bool isCheckBookBorring(int bookID, string userCode)
        {
            database.openConnection();

            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT id FROM borrows WHERE book_id = @bookID AND user_code = @userCode AND status = @status";
            command.Parameters.Add("@bookID", SqlDbType.NVarChar).Value = bookID.ToString();
            command.Parameters.Add("@userCode", SqlDbType.NVarChar).Value = userCode;
            command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status_Borrow.Borrowing.ToString();
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(table);
            if (table.Rows.Count > 0)
                return true;
            return false;
        }

        public static DataTable getListHistoryBorrow(string userCode, string search = null)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("select bo.id AS borrow_id, b.id AS book_id, bookname, bo.status, borrow_time, return_time, b.images from borrows as bo, books as b WHERE bo.book_id = b.id AND bo.user_code = @userCode");
            command.Parameters.Add("@userCode", SqlDbType.NVarChar).Value = userCode;

            if (search != null)
            {
                command.CommandText += " AND bookname LIKE @seach";
                command.Parameters.Add("@seach", SqlDbType.NVarChar).Value = search;
            }

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        public static DataTable getListBookLending(string userCode, string search = null)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("SELECT * FROM teacher_books WHERE user_code = @userCode");
            command.Parameters.Add("@userCode", SqlDbType.NVarChar).Value = userCode;

            if (search != null)
            {
                command.CommandText += " AND CONCAT(bookname,authorname) LIKE @seach";
                command.Parameters.Add("@seach", SqlDbType.NVarChar).Value = search;
            }

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        public static DataTable getInfoOneBookBorrowing(string borrowID, string bookID, string userCode)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("select bookname, authorname, borrows.status, borrow_time, return_time, images, description, price from borrows, books where user_code = @userCode AND book_id = @bookID AND book_id = books.id AND borrows.id = @borrowID");
            command.Parameters.Add("@userCode", SqlDbType.NVarChar).Value = userCode;
            command.Parameters.Add("@bookID", SqlDbType.NVarChar).Value = bookID;
            command.Parameters.Add("@borrowID", SqlDbType.NVarChar).Value = borrowID;
            //command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status_Borrow.Borrowing.ToString();

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        public static DataTable getInfoOneBookBorrowing2(string bookID)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("SELECT * FROM teacher_books WHERE id = @bookID");
            command.Parameters.Add("@bookID", SqlDbType.NVarChar).Value = bookID;

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        public static bool removeTeacherBook(string bookID)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "DELETE FROM teacher_books WHERE id = @bookID";
            command.Parameters.Add("@bookID", SqlDbType.NVarChar).Value = bookID;
            int nRowsAffected = command.ExecuteNonQuery();
            database.closeConnection();
            if (nRowsAffected == 1)
                return true;
            return false;
        }

        public static DataTable getListBorrowingAboutToExpire(string userCode)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format(@"
            select bookname,borrow_time, return_time
            from borrows as bo, books as b
            WHERE bo.book_id = b.id
            AND bo.user_code = @userCode
            AND bo.status = @status
            AND DATEADD(day, 3, @timeNow) >= bo.return_time
            AND @timeNow <= bo.return_time
            ");
            command.Parameters.Add("@userCode", SqlDbType.NVarChar).Value = userCode;
            command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status_Borrow.Borrowing.ToString();
            command.Parameters.Add("@timeNow", SqlDbType.DateTime).Value = DateTime.Now;

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        public static DataTable getListBorrowingExpired(string userCode)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format(@"
            select bookname,borrow_time, return_time
            from borrows as bo, books as b
            WHERE bo.book_id = b.id
            AND bo.user_code = @userCode
            AND bo.status = @status
            AND @timeNow > bo.return_time
            ");
            command.Parameters.Add("@userCode", SqlDbType.NVarChar).Value = userCode;
            command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status_Borrow.Borrowing.ToString();
            command.Parameters.Add("@timeNow", SqlDbType.DateTime).Value = DateTime.Now;

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        public static bool returnBook(string bookID, string userCode)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = @"UPDATE borrows SET status = @status WHERE user_code = @userCode AND book_id = @bookID AND status = @statusOrginal
                                    UPDATE books SET quantity = quantity + 1 WHERE id = @bookID";
            command.Parameters.Add("@statusOrginal", SqlDbType.NVarChar).Value = Status_Borrow.Borrowing.ToString();
            command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status_Borrow.Returned.ToString();
            command.Parameters.Add("@bookID", SqlDbType.NVarChar).Value = bookID;
            command.Parameters.Add("@userCode", SqlDbType.NVarChar).Value = userCode;
            int nRowsAffected = command.ExecuteNonQuery();
            database.closeConnection();
            if (nRowsAffected == 2)
                return true;
            return false;
        }

        public static bool isCheckBookBorrowing(string bookID)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT * FROM borrows WHERE book_id = @bookID AND status = @status";
            command.Parameters.Add("@bookID", SqlDbType.NVarChar).Value = bookID;
            command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status_Borrow.Borrowing.ToString();
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(table);
            if (table.Rows.Count > 0)
                return true;
            return false;
        }

        public static int deleteHistoryBookReturn(string bookID)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "DELETE FROM borrows WHERE book_id = @bookID AND status = @status";
            command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status_Borrow.Returned.ToString();
            command.Parameters.Add("@bookID", SqlDbType.NVarChar).Value = bookID;
            int numberRowsAffected = command.ExecuteNonQuery();
            database.closeConnection();
            return numberRowsAffected;
        }

        public static int deleteHistoryBookReturnWithListBookID(List<string> listBookID)
        {
            string ids = "(";
            foreach(string bookID in listBookID)
            {
                ids += '\'' + bookID + '\'' + ",";
            }
            ids = ids.Trim(',');
            ids += ")";

            if(ids == "()")
            {
                return -1;
            }

            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("DELETE FROM borrows WHERE book_id IN {0} AND status = '{1}'", ids, Borrows.Status_Borrow.Returned.ToString());
            
            int numberRowsAffected = command.ExecuteNonQuery();
            database.closeConnection();
            return numberRowsAffected;
        }
    }
}