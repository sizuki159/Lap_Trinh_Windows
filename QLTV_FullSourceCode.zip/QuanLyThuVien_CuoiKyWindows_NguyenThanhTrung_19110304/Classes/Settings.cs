﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes
{
    public class Settings
    {
        private static Database database = new Database();

        public static string KeyGmail = "gmail";
        public static string KeyPassEmail = "passemail";
        public static string KeyHourOpen = "hourOpen";
        public static string KeyHourClose = "hourClose";
        public static string KeyTotalManager = "totalManager";
        public static string KeyTotalArranger = "totalArranger";
        public static string KeyTotalDelivery = "totalDelivery";


        public static DataTable getDataSettings()
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT * FROM settings";
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        public static string getValue(string key)
        {
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT value FROM settings WHERE keys = @key";
            command.Parameters.Add("@key", SqlDbType.NVarChar).Value = key;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            if (table.Rows.Count > 0)
                return table.Rows[0]["value"].ToString();
            return string.Empty;
        }

        public static bool updateValue(string key, string value)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "UPDATE settings SET value = @value WHERE keys = @key";
            command.Parameters.Add("@key", SqlDbType.NVarChar).Value = key;
            command.Parameters.Add("@value", SqlDbType.NVarChar).Value = value;
            int numberRowAffected = command.ExecuteNonQuery();
            database.closeConnection();
            if (numberRowAffected > 0)
                return true;
            return false;
        }

        public static bool updateEmail(string email, string pass)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = @"UPDATE settings SET value = @email WHERE keys = @keyGmail
                                    UPDATE settings SET value = @pass WHERE keys = @keyPassemail";
            command.Parameters.Add("@email", SqlDbType.NVarChar).Value = email;
            command.Parameters.Add("@pass", SqlDbType.NVarChar).Value = pass;
            command.Parameters.Add("@keyGmail", SqlDbType.NVarChar).Value = KeyGmail;
            command.Parameters.Add("@keyPassemail", SqlDbType.NVarChar).Value = KeyPassEmail;

            int numberRowAffected = command.ExecuteNonQuery();
            database.closeConnection();
            if (numberRowAffected == 2)
                return true;
            return false;
        }
    }
}
