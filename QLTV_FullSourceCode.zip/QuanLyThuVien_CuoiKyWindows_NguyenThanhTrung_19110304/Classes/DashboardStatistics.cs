﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes
{
    public class DashboardStatistics
    {
        public static Database database = new Database();

        public static Int32 countAllRowsInTable(string tableName, params string[] condition)
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = "SELECT COUNT(id) FROM " + tableName;
            if (condition.Length > 0)
                command.CommandText += string.Format(" WHERE {0} {1} '{2}'", condition[0], condition[1], condition[2]);
            database.openConnection();
            command.Connection = database.getConnection;
            object result = command.ExecuteScalar();
            if (result == null)
                return -1;
            return (Int32)result;
        }

        public static Int32 countGenderUsers(string gender)
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = "SELECT COUNT(id) FROM users WHERE gender = '" + gender + '\'';
            database.openConnection();
            command.Connection = database.getConnection;
            object result = command.ExecuteScalar();
            if (result == null)
                return -1;
            return (Int32)result;
        }

        public static string[] getTop5Book()
        {
            SqlCommand command = new SqlCommand();
            command.CommandText = "select COUNT(borrows.id) AS total, book_id, bookname from borrows, books where borrows.book_id = books.id GROUP BY book_id, bookname ORDER BY total DESC";
            database.openConnection();
            command.Connection = database.getConnection;
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(table);

            if(table.Rows.Count > 0)
            {
                string[] result = new string[5];
                for(int i = 0; i < table.Rows.Count && i < 5; i++)
                {
                    result[i] = (i + 1).ToString() + ". " + table.Rows[i]["bookname"].ToString();
                }
                return result;
            }
            return null;
        }
    }
}
