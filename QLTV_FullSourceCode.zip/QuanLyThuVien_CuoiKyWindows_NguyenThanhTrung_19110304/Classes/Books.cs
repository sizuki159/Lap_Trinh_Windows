﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes
{
    public partial class Books
    {
        public static Database database = new Database();

        #region Property
        private const string TableName = "books";

        public string Name { get; set; }
        public string AuthorName { get; set; }
        public int BookType { get; set; }
        public float Price { get; set; }
        public int Quantity { get; set; }
        public string Description { get; set; }
        public Book_Status Status { get; set; }

        public Image Image { get; set; }

        public enum Book_Status
        {
            Active,
            Hiden,
            Pending
        }

        #endregion

        #region Contructor
        public Books() { }

        public Books(string name)
        {
            Name = name;
        }
        #endregion

        // Thêm data vào database
        public bool isInsert()
        {
            Database database = new Database();
            database.openConnection();

            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "INSERT INTO " + TableName + "(bookname, authorname, booktype, price, quantity, description, status, images, created_time)" +
                                    "VALUES(@name, @author, @type, @price, @quantity, @description, @status, @images, @created)";
            command.Parameters.Add("@name", System.Data.SqlDbType.NVarChar).Value = Name;
            command.Parameters.Add("@author", System.Data.SqlDbType.NVarChar).Value = AuthorName;
            command.Parameters.Add("@type", System.Data.SqlDbType.Int).Value = BookType;
            command.Parameters.Add("@price", System.Data.SqlDbType.Float).Value = Price;
            command.Parameters.Add("@quantity", System.Data.SqlDbType.Int).Value = Quantity;
            command.Parameters.Add("@description", System.Data.SqlDbType.NVarChar).Value = Description;
            command.Parameters.Add("@status", System.Data.SqlDbType.VarChar).Value = Status;

            if (Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    Image.Save(ms, ImageFormat.Png);
                    command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = ms.ToArray();
                }
            }
            else
                command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = DBNull.Value;


            command.Parameters.Add("@created", System.Data.SqlDbType.DateTime).Value = DateTime.Now;

            if (command.ExecuteNonQuery() == 1)
            {
                database.closeConnection();
                return true;
            }
            database.closeConnection();
            return false;
        }

        public bool isInsert2(string userCode)
        {
            Database database = new Database();
            database.openConnection();

            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "INSERT INTO " + "teacher_books" + "(bookname, authorname, booktype, price, quantity, description, status, images, user_code)" +
                                    "VALUES(@name, @author, @type, @price, @quantity, @description, @status, @images, @userCode)";
            command.Parameters.Add("@name", System.Data.SqlDbType.NVarChar).Value = Name;
            command.Parameters.Add("@author", System.Data.SqlDbType.NVarChar).Value = AuthorName;
            command.Parameters.Add("@type", System.Data.SqlDbType.Int).Value = BookType;
            command.Parameters.Add("@price", System.Data.SqlDbType.Float).Value = Price;
            command.Parameters.Add("@quantity", System.Data.SqlDbType.Int).Value = Quantity;
            command.Parameters.Add("@description", System.Data.SqlDbType.NVarChar).Value = Description;
            command.Parameters.Add("@status", System.Data.SqlDbType.NVarChar).Value = "lending";
            command.Parameters.Add("@userCode", System.Data.SqlDbType.NVarChar).Value = userCode;

            if (Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    Image.Save(ms, ImageFormat.Png);
                    command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = ms.ToArray();
                }
            }
            else
                command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = DBNull.Value;


            if (command.ExecuteNonQuery() == 1)
            {
                database.closeConnection();
                return true;
            }
            database.closeConnection();
            return false;
        }

        // Load dữ liệu cho combobox book type
        public static bool loadComboBoxBookType(ComboBox comboBox, params object[] exceptID)
        {

            List<Book_Type> booktype = new List<Book_Type>();

            if (exceptID.Length > 0)
            {
                if (!bool.Parse(exceptID[0].ToString()))
                    booktype = Book_Type.getListBookType();
                else
                    booktype = Book_Type.getListBookType(exceptID[1].ToString());
            }
            else
                booktype = Book_Type.getListBookType();

            comboBox.DataSource = booktype;
            comboBox.DisplayMember = "Name";
            return true;
        }

        // Check Quantity Book
        public static bool isCheckBookAvailableQuantity(string bookID)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT dbo.CheckBooksQuantity('" + bookID + "') AS isAvailable";
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(table);
            if (bool.Parse(table.Rows[0]["isAvailable"].ToString()))
                return true;
            return false;
        }

        // Subtract 1 quantity from book With ID book
        public static bool isTakeOneBook(string bookID)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "EXECUTE TakeOneBookWithID " + bookID;
            if (command.ExecuteNonQuery() > 0)
                return true;
            return false;
        }

        #region Get List Books
        //Get toàn bộ danh sách books
        public static DataTable getBooks()
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT * FROM listBook";

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        // Get danh sách book with status book truyền vào
        public static DataTable getBooksWithStatus(Book_Status status, Book_Type.BookType_Status? bookTypeStatus = null, string search = null)
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT books.id AS book_id, bookname, authorname, typename, price, quantity, description, books.status, images, books.created_time, books.modified_time FROM books, book_type WHERE books.booktype = book_type.id AND books.status = @status";
            if (bookTypeStatus != null)
            {
                command.CommandText += " AND book_type.status = @statusType";
                command.Parameters.Add("@statusType", SqlDbType.NVarChar).Value = bookTypeStatus.ToString();
            }
            if(search != null)
            {
                command.CommandText += " AND CONCAT(bookname, authorname, typename) LIKE @seach";
                command.Parameters.Add("@seach", SqlDbType.NVarChar).Value = search;
            }

            command.Parameters.Add("@status", SqlDbType.NVarChar).Value = status.ToString();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        // Get thông tin một cuốn sách với ID sách truyền vào
        public static DataTable getBookWithID(string id)
        {
            Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("SELECT * FROM getInfoBookWithID({0})", id);

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);

            return table;
        }

        // Get danh sách book có name truyền vào -> ở đây là chức năng filter (Search)
        public static DataTable getBookWithBookName(string bookName)
        {
            //Database database = new Database();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "SELECT books.id AS book_id, bookname, authorname, typename, price, quantity, description, books.status, images, books.created_time, books.modified_time FROM books, book_type WHERE books.booktype = book_type.id AND CONCAT(bookname, authorname, typename) LIKE @name";
            command.Parameters.Add("@name", SqlDbType.NVarChar).Value = '%' + bookName + '%';
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        public static List<string> getListBookIDWithBookTypeID(string bookTypeID)
        {
            List<string> listBookID = new List<string>();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = string.Format("SELECT id FROM books WHERE booktype = @bookTypeID");
            command.Parameters.Add("@bookTypeID", SqlDbType.NVarChar).Value = bookTypeID;
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(table);
            if(table.Rows.Count > 0)
            {
                for(int i = 0; i < table.Rows.Count; i++)
                {
                    listBookID.Add(table.Rows[i]["id"].ToString());
                }
            }
            return listBookID;
        }

        #endregion

        #region Delete Book



        public static bool deleteBookWithID(string id)
        {
            Database database = new Database();
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "EXECUTE deleteBookWithID @id";
            command.Parameters.Add("@id", SqlDbType.VarChar).Value = id;
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(table);
            if (int.Parse(table.Rows[0]["rowsDelete"].ToString()) > 0)
                return true;

            return false;
        }
        public static bool deleteAllBookWithBookTypeID(string bookTypeID)
        {
            Database database = new Database();
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "EXECUTE deleteAllBookWithBookTypeID @id";
            command.Parameters.Add("@id", SqlDbType.VarChar).Value = bookTypeID;
            DataTable table = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(table);
            if (int.Parse(table.Rows[0]["rowsDelete"].ToString()) > 0)
                return true;
            return false;
        }

        #endregion

        #region Update Book
        public bool isUpdateBook(string BookID)
        {
            Database database = new Database();
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "UPDATE books SET bookname = @name, authorname = @author, booktype = @type, price = @price, quantity = @quantity, description = @description, status = @status, images = @images, modified_time = @modified " +
                                "WHERE id = @bookID";


            command.Parameters.Add("@name", System.Data.SqlDbType.NVarChar).Value = Name;
            command.Parameters.Add("@author", System.Data.SqlDbType.NVarChar).Value = AuthorName;
            command.Parameters.Add("@type", System.Data.SqlDbType.Int).Value = BookType;
            command.Parameters.Add("@price", System.Data.SqlDbType.Float).Value = Price;
            command.Parameters.Add("@quantity", System.Data.SqlDbType.Int).Value = Quantity;
            command.Parameters.Add("@description", System.Data.SqlDbType.Text).Value = Description;
            command.Parameters.Add("@status", System.Data.SqlDbType.VarChar).Value = Status;

            if (Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    Image.Save(ms, ImageFormat.Png);
                    command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = ms.ToArray();
                }
            }
            else
                command.Parameters.Add("@images", System.Data.SqlDbType.Image).Value = DBNull.Value;

            command.Parameters.Add("@modified", SqlDbType.DateTime).Value = DateTime.Now;
            command.Parameters.Add("@bookID", SqlDbType.Int).Value = int.Parse(BookID);

            if (command.ExecuteNonQuery() == 1)
                return true;

            return false;
        }
        public static bool isUpdatBookTypeID(string typeIDCurrent, string newTypeTD)
        {
            Database database = new Database();
            database.openConnection();
            SqlCommand command = new SqlCommand();
            command.Connection = database.getConnection;
            command.CommandText = "UPDATE books SET booktype = @newID WHERE booktype = @curID";
            command.Parameters.Add("@newID", SqlDbType.NVarChar).Value = newTypeTD;
            command.Parameters.Add("@curID", SqlDbType.NVarChar).Value = typeIDCurrent;
            if (command.ExecuteNonQuery() > 0)
                return true;
            return false;
        }

        #endregion

        #region Count Book
        public static Int32 countBooksWithBookTypeID(string bookTypeID)
        {
            SqlCommand command = new SqlCommand("SELECT COUNT(id) FROM books WHERE booktype = @bookTypeID GROUP BY booktype");
            command.Parameters.Add("@bookTypeID", SqlDbType.NVarChar).Value = bookTypeID;
            database.openConnection();
            command.Connection = database.getConnection;
            object result = command.ExecuteScalar();
            if (result == null)
                return -1;
            return (Int32)result;
        }

        #endregion
    }

    public partial class Books
    {
        public class Book_Type
        {
            public enum BookType_Status
            {
                Active,
                Inactive,
                Hiden
            }
            public string Name { get; set; }
            public string ID { get; private set; }
            public BookType_Status Status { get; set; }


            // Get Data from CSDL rồi chuyển thành List
            public static List<Book_Type> getListBookType(string exceptID = "")
            {
                Database database = new Database();
                SqlCommand command = new SqlCommand();
                command.Connection = database.getConnection;
                if (string.IsNullOrEmpty(exceptID))
                    command.CommandText = "SELECT * FROM book_type";
                else
                    command.CommandText = "SELECT * FROM book_type WHERE id <> " + exceptID;
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet);


                if (dataSet.Tables.Count > 0)
                {
                    List<Book_Type> listBook = new List<Book_Type>();
                    for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                    {
                        Book_Type booktype = new Book_Type();
                        booktype.ID = dataSet.Tables[0].Rows[i]["id"].ToString();
                        booktype.Name = dataSet.Tables[0].Rows[i]["typename"].ToString();
                        listBook.Add(booktype);
                    }
                    return listBook;
                }
                return null;
            }

            public static DataTable getBookType()
            {
                Database database = new Database();
                SqlCommand command = new SqlCommand();
                command.Connection = database.getConnection;
                command.CommandText = "SELECT * FROM book_type";

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);

                return table;
            }

            public static DataTable getBookTypeWithID(string id)
            {
                Database database = new Database();
                SqlCommand command = new SqlCommand();
                command.Connection = database.getConnection;
                command.CommandText = string.Format("SELECT * FROM getInfoBookTypeWithID({0})", id);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);

                return table;
            }

            public static bool isCheckTypeNameExist(string typename)
            {
                Database database = new Database();
                SqlCommand command = new SqlCommand();
                command.Connection = database.getConnection;
                command.CommandText = "SELECT id FROM book_type WHERE typename = @typename";
                command.Parameters.Add("@typename", SqlDbType.NVarChar).Value = typename;
                DataTable table = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(table);
                if (table.Rows.Count > 0)
                    return true;
                return false;
            }

            public bool isInsert()
            {
                Database database = new Database();
                database.openConnection();

                SqlCommand command = new SqlCommand();
                command.Connection = database.getConnection;
                command.CommandText = "INSERT INTO book_type(typename, status, created_time) VALUES(@typename, @status, @created)";

                command.Parameters.Add("@typename", SqlDbType.NVarChar).Value = Name;
                command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status;
                command.Parameters.Add("@created", System.Data.SqlDbType.DateTime).Value = DateTime.Now;

                if (command.ExecuteNonQuery() == 1)
                {
                    database.closeConnection();
                    return true;
                }
                database.closeConnection();
                return false;
            }

            public static bool isDeleteBookTypeWithID(string id)
            {
                Database database = new Database();
                database.openConnection();
                SqlCommand command = new SqlCommand();
                command.Connection = database.getConnection;
                command.CommandText = "EXECUTE deleteBookTypeWithID @id";
                command.Parameters.Add("@id", SqlDbType.NVarChar).Value = id;
                DataTable table = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(table);
                if (int.Parse(table.Rows[0]["rowsDelete"].ToString()) > 0)
                    return true;

                return false;
            }

            public bool isUpdateBookType(string bookTypeID)
            {
                Database database = new Database();
                database.openConnection();
                SqlCommand command = new SqlCommand();
                command.Connection = database.getConnection;
                command.CommandText = "UPDATE book_type SET typename = @typename, status = @status, modified_time = @modified WHERE id = @id";
                command.Parameters.Add("@typename", SqlDbType.NVarChar).Value = Name;
                command.Parameters.Add("@status", SqlDbType.NVarChar).Value = Status;
                command.Parameters.Add("@modified", SqlDbType.DateTime).Value = DateTime.Now;
                command.Parameters.Add("@id", SqlDbType.NVarChar).Value = bookTypeID;
                if (command.ExecuteNonQuery() == 1)
                    return true;
                return false;
            }
        }
    }
}