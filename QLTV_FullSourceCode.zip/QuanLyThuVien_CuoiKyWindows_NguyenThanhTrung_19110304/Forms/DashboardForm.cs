﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Books;
using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes;
using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Users;
using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.BorrowBooks;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms
{
    public partial class DashboardForm : Form
    {
        private string userCode = Classes.Users.InfoUserLogin["code"].ToString();
        public DashboardForm()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you close program?", "Close Program", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Application.Exit();
        }

        private void addNewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Classes.TrungHelper.boolSendEmailRecoverAccount("quocthaierror@gmail.com");
            AddBooksForm addBooksForm = new AddBooksForm();
            addBooksForm.ShowDialog();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            // Kiểm tra người dùng đã login chưa
            if (!Classes.Users.isLogin)
                Application.Exit();

            lendsBookToolStripMenuItem.Visible = false;

            string role = Classes.Users.InfoUserLogin["role"].ToString();

            // Phân quyền chức năng
            if(role == Classes.Users.User_Role.Student.ToString())
            {
                booksToolStripMenuItem.Visible = false;
                usersToolStripMenuItem.Visible = false;
                settingsToolStripMenuItem.Visible = false;
                lendsBookToolStripMenuItem.Visible = false;
            }
            else if(role == Classes.Users.User_Role.Teacher.ToString())
            {
                booksToolStripMenuItem.Visible = false;
                usersToolStripMenuItem.Visible = false;
                settingsToolStripMenuItem.Visible = false;
                lendsBookToolStripMenuItem.Visible = true;
            }

            lbUsername.Text = string.Format("Hello: {0}\nRole: {1}", Classes.Users.InfoUserLogin["fullname"], Classes.Users.InfoUserLogin["role"]);

            #region Dashboard Statistics

            // Users
            {
                int totalUsers = DashboardStatistics.countAllRowsInTable("users");
                int totalTeacher = DashboardStatistics.countAllRowsInTable("users", "role", "=", Classes.Users.User_Role.Teacher.ToString());
                int totalStudent = DashboardStatistics.countAllRowsInTable("users", "role", "=", Classes.Users.User_Role.Student.ToString());
                lbTotalUsers.Text = totalUsers.ToString();
                lbTotalTeacher.Text = totalTeacher.ToString();
                lbTotalStudent.Text = totalStudent.ToString();
            }

            // Employee
            {
                int totalEmployee = DashboardStatistics.countAllRowsInTable("employee");
                int totalManager = DashboardStatistics.countAllRowsInTable("employee", "working", "=", Classes.Employee.Job.Manager.ToString());
                int totalDelivery = DashboardStatistics.countAllRowsInTable("employee", "working", "=", Classes.Employee.Job.Delivery.ToString());
                int totalArranger = DashboardStatistics.countAllRowsInTable("employee", "working", "=", Classes.Employee.Job.Arranger.ToString());
                lbTotalEmployee.Text = totalEmployee.ToString();
                lbTotalArranger.Text = totalArranger.ToString();
                lbTotalDelivery.Text = totalDelivery.ToString();
                lbTotalManager.Text = totalManager.ToString();
            }

            // Books
            {
                int totalBookType = DashboardStatistics.countAllRowsInTable("book_type");
                int totalBooks = DashboardStatistics.countAllRowsInTable("books");
                int totalBorrows = DashboardStatistics.countAllRowsInTable("borrows");
                int totalBookBorrowing = DashboardStatistics.countAllRowsInTable("borrows", "status", "=", Classes.Borrows.Status_Borrow.Borrowing.ToString());
                int totalBookReturned = DashboardStatistics.countAllRowsInTable("borrows", "status", "=", Classes.Borrows.Status_Borrow.Returned.ToString());
                lbTotalCategories.Text = totalBookType.ToString();
                lbTotalBooks.Text = totalBooks.ToString();
                lbTotalBorrow.Text = totalBorrows.ToString();
                lbTotalBorrowing.Text = totalBookBorrowing.ToString();
                lbTotalBookReturned.Text = totalBookReturned.ToString();
            }

            // Book yeu thich nhat
            {
                string[] listBookTop5 = Classes.DashboardStatistics.getTop5Book();

                if(listBookTop5 != null && listBookTop5.Length > 0)
                {
                    lbBook1.Text = string.IsNullOrEmpty(listBookTop5[0]) ? "Khong co" : listBookTop5[0];
                    lbBook2.Text = string.IsNullOrEmpty(listBookTop5[1]) ? "Khong co" : listBookTop5[1];
                    lbBook3.Text = string.IsNullOrEmpty(listBookTop5[2]) ? "Khong co" : listBookTop5[2];
                    lbBook4.Text = string.IsNullOrEmpty(listBookTop5[3]) ? "Khong co" : listBookTop5[3];
                    lbBook5.Text = string.IsNullOrEmpty(listBookTop5[4]) ? "Khong co" : listBookTop5[4];
                }
                else
                {

                }
            }




            //int totalUsersFemale = DashboardStatistics.countGenderUsers("Female");
            //int totalUsersMale = DashboardStatistics.countGenderUsers("Male");
            //chartGenderUsers.Series["Gender"].Points.AddXY("Female", totalUsersFemale);
            //chartGenderUsers.Series["Gender"].Points.AddXY("Male", totalUsersMale);
            //chartGenderUsers.Series["Status"].Points.AddXY("Ban", 10);
            //chartGenderUsers.Series["Status"].Points.AddXY("Acitve", 100);
            //chartGenderUsers.Series["Gender"].ShadowColor = Color.Black;

            #endregion


            #region Thông báo sách sắp hết hạn và đã hết hạn
            // Thông báo sách sắp hết hạn và đã hết hạn
            string messages = string.Empty;

            DataTable listBookAboutToExpire = Classes.Borrows.getListBorrowingAboutToExpire(userCode);
            if (listBookAboutToExpire.Rows.Count > 0)
            {
                messages = string.Format("- Bạn đang có {0} cuốn sách sắp đến hạn trả\n", listBookAboutToExpire.Rows.Count);
                foreach (DataRow row in listBookAboutToExpire.Rows)
                {
                    messages += string.Format("\t+ {0} - cần trả trước {1}\n", row["bookname"].ToString(), row["return_time"].ToString());
                }
                messages += "\n\n";
            }
            DataTable listBorrowingExpired = Classes.Borrows.getListBorrowingExpired(userCode);
            if (listBorrowingExpired.Rows.Count > 0)
            {
                messages += string.Format("- Bạn đã quá hạn {0} cuốn sách\n", listBorrowingExpired.Rows.Count);
                foreach (DataRow row in listBorrowingExpired.Rows)
                {
                    messages += string.Format("\t+ {0} - cần trả trước {1}\n", row["bookname"].ToString(), row["return_time"].ToString());
                }
            }
            if (messages != string.Empty)
                MessageBox.Show(messages, "Notification Return Book", MessageBoxButtons.OK, MessageBoxIcon.Information);
            #endregion
        }

        private void viewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewBooksForm vb = new ViewBooksForm();
            vb.ShowDialog();
        }

        private void bookTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBookTypeForm addBookTypeForm = new AddBookTypeForm();
            addBookTypeForm.ShowDialog();
        }

        private void addUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddUsersForm addUsersForm = new AddUsersForm();
            addUsersForm.ShowDialog();
        }

        private void viewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewUsersForm vu = new ViewUsersForm();
            vu.ShowDialog();
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            settings.ShowDialog();
        }

        private void myAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditMyAccountForm editMyAccountForm = new EditMyAccountForm();
            editMyAccountForm.ShowDialog();
        }

        private void issueBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MenuBooksForm menuBooksForm = new MenuBooksForm();
            menuBooksForm.ShowDialog();
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewListBookBorrowingForm viewListBookBorrowingForm = new ViewListBookBorrowingForm();
            viewListBookBorrowingForm.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void lendBookToLibraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TeacherAddBooks teacherAddBooks = new TeacherAddBooks();
            teacherAddBooks.ShowDialog();
        }

        private void myListBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TeacherListBook teacherListBook = new TeacherListBook();
            teacherListBook.ShowDialog();
        }
    }
}
