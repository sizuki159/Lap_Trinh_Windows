﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms
{
    public partial class Settings : Form
    {
        public Settings()
        {
            InitializeComponent();
            dataGirdScheduledWorker.Visible = false;
        }

        private void loadDataAllControl()
        {
            string gmail = Classes.Settings.getValue(Classes.Settings.KeyGmail);
            string passEmail = Classes.Settings.getValue(Classes.Settings.KeyPassEmail);
            int hourOpen = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyHourOpen));
            int hourClose = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyHourClose));
            int totalManager = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyTotalManager));
            int totalDelivery = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyTotalDelivery));
            int totalArranger = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyTotalArranger));

            txbGmail.Text = gmail;
            txbPassGmail.Text = passEmail;
            numericUpDownOpen.Value = hourOpen;
            numericUpDownClose.Value = hourClose;
            numericUpDownManager.Value = totalManager;
            numericUpDownDelivery.Value = totalDelivery;
            numericUpDownArranger.Value = totalArranger;
        }

        private void Settings_Load(object sender, EventArgs e)
        {
            loadDataAllControl();
        }

        private void btnSaveGmail_Click(object sender, EventArgs e)
        {
            string newEmail = txbGmail.Text;
            string newPassEmail = txbPassGmail.Text;

            if (!newEmail.Contains("@gmail.com"))
            {
                MessageBox.Show("Hiện tại chỉ hỗ trợ Gmail. Vui lòng nhập đúng định dạng của Gmail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool isUpdated = Classes.Settings.updateEmail(newEmail, newPassEmail);
            if (isUpdated)
            {
                MessageBox.Show("Update Email Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                loadDataAllControl();
            }
        }

        private void btnSaveTime_Click(object sender, EventArgs e)
        {
            int hourOpen = Convert.ToInt32(numericUpDownOpen.Value);
            int hourClose = Convert.ToInt32(numericUpDownClose.Value);


            if (hourOpen >= hourClose)
            {
                MessageBox.Show("Thời gian không hợp lệ, thời gian đóng cửa lại sớm hơn mở cửa ??? :D ???", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (Classes.Settings.updateValue(Classes.Settings.KeyHourOpen, hourOpen.ToString()) && Classes.Settings.updateValue(Classes.Settings.KeyHourClose, hourClose.ToString()))
            {
                MessageBox.Show("Update Hour Library Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void btnSaveEmployee_Click(object sender, EventArgs e)
        {
            int numberManager = Convert.ToInt32(numericUpDownManager.Value);
            int numberDelivery = Convert.ToInt32(numericUpDownDelivery.Value);
            int numberArranger = Convert.ToInt32(numericUpDownArranger.Value);

            if (
                Classes.Settings.updateValue(Classes.Settings.KeyTotalManager, numberManager.ToString())
                && Classes.Settings.updateValue(Classes.Settings.KeyTotalDelivery, numberDelivery.ToString())
                && Classes.Settings.updateValue(Classes.Settings.KeyTotalArranger, numberArranger.ToString())
                )
            {
                MessageBox.Show("Update Number Employee Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Update Errors", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btnScheduled_Click(object sender, EventArgs e)
        {
            int totalMinute = (Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyHourClose)) - Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyHourOpen))) * 60;
            int ca = 2;
            int minuteOneCa = totalMinute / ca;

            TimeSpan timeStartC1 = new TimeSpan(Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyHourOpen)), 0, 0);
            TimeSpan timeStartC2 = timeStartC1.Add(new TimeSpan(0, minuteOneCa, 0));

            DataTable allEmployee = Classes.Employee.getEmployee();
            List<Classes.Employee> listManager = new List<Classes.Employee>();
            List<Classes.Employee> listDelivery = new List<Classes.Employee>();
            List<Classes.Employee> listArranger = new List<Classes.Employee>();


            foreach (DataRow row in allEmployee.Rows)
            {
                Classes.Employee employee = new Classes.Employee();
                employee.ID = row["id"].ToString();
                employee.Fullname = row["fullname"].ToString();
                employee.Email = row["email"].ToString();
                employee.Birthdate = Convert.ToDateTime(row["birthdate"].ToString());

                if (row["working"].ToString() == Classes.Employee.Job.Manager.ToString())
                {
                    employee.Working = Classes.Employee.Job.Manager;
                    listManager.Add(employee);
                }
                else if (row["working"].ToString() == Classes.Employee.Job.Delivery.ToString())
                {
                    employee.Working = Classes.Employee.Job.Delivery;
                    listDelivery.Add(employee);
                }
                else
                {
                    employee.Working = Classes.Employee.Job.Arranger;
                    listArranger.Add(employee);
                }
            }

            int totalManager = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyTotalManager));
            int totalDelivery = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyTotalDelivery));
            int totalArranger = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyTotalArranger));

            #region Xử lý cho Employee Manager
            int minutePerManagerWorking = Convert.ToInt32(totalMinute / totalManager);
            for (int i = 0; i < totalManager; i++)
            {
                listManager[i].TimeStartWorking = timeStartC1.Add(new TimeSpan(0, i * minutePerManagerWorking, 0));
                listManager[i].TimeEndWorking = timeStartC1.Add(new TimeSpan(0, (i + 1) * minutePerManagerWorking, 0));
            }
            #endregion
            #region Xử lý cho Employee Delivery
            {
                int numberEmployeeOneCa = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(totalDelivery) / 2));
                if (totalDelivery % 2 == 0)
                {
                    numberEmployeeOneCa = totalDelivery / 2;
                }
                int nTemp = -1;
                for (int i = 0; i < numberEmployeeOneCa; i++)
                {
                    listDelivery[i].TimeStartWorking = timeStartC1;
                    listDelivery[i].TimeEndWorking = timeStartC2;
                    nTemp = i;
                }
                for (int i = nTemp + 1; i < totalDelivery; i++)
                {
                    listDelivery[i].TimeStartWorking = timeStartC2;
                    listDelivery[i].TimeEndWorking = timeStartC2.Add(new TimeSpan(0, minuteOneCa, 0));
                }
            }
            #endregion
            #region Xử lý cho Employee Arranger
            {
                int numberEmployeeOneCa = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(totalArranger) / 2));
                if (totalArranger % 2 == 0)
                {
                    numberEmployeeOneCa = totalArranger / 2;
                }
                int nTemp = -1;
                for (int i = 0; i < numberEmployeeOneCa; i++)
                {
                    listArranger[i].TimeStartWorking = timeStartC1;
                    listArranger[i].TimeEndWorking = timeStartC2;
                    nTemp = i;
                }
                for (int i = nTemp + 1; i < totalArranger; i++)
                {
                    listArranger[i].TimeStartWorking = timeStartC2;
                    listArranger[i].TimeEndWorking = timeStartC2.Add(new TimeSpan(0, minuteOneCa, 0));
                }
            }
            #endregion




            List<Classes.Employee> listFullScheduledWorker = listManager.Concat(listDelivery)
                                    .Concat(listArranger)
                                    .ToList();



            for (int i = 0; i < listFullScheduledWorker.Count; i++)
            {
                if (listFullScheduledWorker[i].TimeStartWorking.TotalSeconds <= 0)
                {
                    listFullScheduledWorker.RemoveAt(i);
                    i--;
                }
            }

            var source = new BindingSource();
            source.DataSource = listFullScheduledWorker;
            dataGirdScheduledWorker.DataSource = source;
            dataGirdScheduledWorker.Columns["ID"].HeaderText = "User ID";
            dataGirdScheduledWorker.Columns["Fullname"].HeaderText = "Ho Ten";
            dataGirdScheduledWorker.Columns["Working"].HeaderText = "Cong viec";
            dataGirdScheduledWorker.Columns.Remove("birthdate");
            dataGirdScheduledWorker.Columns["TimeStartWorking"].HeaderText = "Time Start";
            dataGirdScheduledWorker.Columns["TimeEndWorking"].HeaderText = "Time End";


            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Word Documents (*.docx)|*.docx";
            sfd.FileName = "LichLamNhanVien.docx";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                this.Export_Data_ToFile_Word(dataGirdScheduledWorker, sfd.FileName);
                MessageBox.Show(String.Format("Saved data to file {0}", sfd.FileName), "saved success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        private void Export_Data_ToFile_Word(DataGridView DGV, string filename)
        {
            if (DGV.Rows.Count > 0)
            {
                int RowCount = DGV.Rows.Count;
                int ColumnCount = DGV.Columns.Count;

                Object[,] DataArray = new object[RowCount + 1, ColumnCount + 1];

                int r = 0;
                for (int c = 0; c <= ColumnCount - 1; c++)
                {
                    for (r = 0; r <= RowCount - 1; r++)
                    {
                        DataArray[r, c] = DGV.Rows[r].Cells[c].Value;
                    }
                }

                Word.Document oDoc = new Word.Document();
                oDoc.Application.Visible = true;

                oDoc.PageSetup.Orientation = Word.WdOrientation.wdOrientLandscape;
                dynamic oRange = oDoc.Content.Application.Selection.Range;
                string oTemp = "";
                for (r = 0; r <= RowCount - 1; r++)
                {
                    for (int c = 0; c <= ColumnCount - 1; c++)
                    {
                        oTemp += DataArray[r, c] + "\t";
                    }
                }
                oRange.Text = oTemp;

                object Separator = Word.WdTableFieldSeparator.wdSeparateByTabs;
                object ApplyBorders = true;
                object AutoFit = true;
                object AutoFitBehavior = Word.WdAutoFitBehavior.wdAutoFitContent;

                oRange.ConvertToTable(ref Separator, ref RowCount, ref ColumnCount,
                                        Type.Missing, Type.Missing, ref ApplyBorders,
                                        Type.Missing, Type.Missing, Type.Missing,
                                        Type.Missing, ref AutoFit, ref AutoFitBehavior, Type.Missing
                                                );
                oRange.Select();

                oRange.Application.Selection.Tables[1].Select();
                oRange.Application.Selection.Tables[1].Rows.AllowBreakAcrossPages = 0;
                oRange.Application.Selection.Tables[1].Rows.Alignment = 0;
                oRange.Application.Selection.Tables[1].Rows[1].Select();
                oRange.Application.Selection.InsertRowsAbove(1);
                oRange.Application.Selection.Tables[1].Rows[1].Select();

                oDoc.Application.Selection.Tables[1].Rows[1].Range.Bold = 1;
                oDoc.Application.Selection.Tables[1].Rows[1].Range.Font.Name = "Tahoma";
                oDoc.Application.Selection.Tables[1].Rows[1].Range.Font.Size = 14;

                for (int c = 0; c <= ColumnCount - 1; c++)
                {
                    oDoc.Application.Selection.Tables[1].Cell(1, c + 1).Range.Text = DGV.Columns[c].HeaderText;
                }

                oDoc.Application.Selection.Tables[1].set_Style("Grid Table 4 - Accent 5");
                oDoc.Application.Selection.Tables[1].Rows[1].Select();
                oDoc.Application.Selection.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;

                foreach (Word.Section section in oDoc.Application.ActiveDocument.Sections)
                {
                    Word.Range headerRange = section.Headers[Word.WdHeaderFooterIndex.wdHeaderFooterPrimary].Range;
                    headerRange.Fields.Add(headerRange, Word.WdFieldType.wdFieldPage);
                    headerRange.Text = "Lịch làm việc của nhân viên thư viện HCMUTE vào ngày " + DateTime.Now.AddDays(1).ToString("dd/MM/yyyy");
                    headerRange.Font.Size = 16;
                    headerRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                }
                oDoc.SaveAs2(filename);

            }
        }
    }
}