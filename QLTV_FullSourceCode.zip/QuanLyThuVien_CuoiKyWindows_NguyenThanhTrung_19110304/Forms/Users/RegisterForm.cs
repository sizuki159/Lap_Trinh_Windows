﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Users
{
    public partial class RegisterForm : Form
    {
        private string captcha = string.Empty;

        public RegisterForm()
        {
            InitializeComponent();
        }

        private void btnUploadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.png; *.jpeg; *.gif; *.bmp)|*.jpg; *.png; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBoxImage.Image = new Bitmap(open.FileName);
            }
        }

        private void loadImageCaptcha()
        {
            captcha = Classes.TrungHelper.RandomString(6);
            var img = new Bitmap(pictureBoxImage.Width, pictureBoxImage.Height);
            var font = new Font("Arial", 30, FontStyle.Bold, GraphicsUnit.Pixel);
            var graphics = Graphics.FromImage(img);
            graphics.DrawString(captcha, font, Brushes.Red, new Point(0, 0));
            pictureBoxCaptcha.Image = img;
        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {
            loadImageCaptcha();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if(!validateForm())
            {
                MessageBox.Show("Validate Fail", "Validate Form Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if(txbInputCaptcha.Text != captcha)
            {
                MessageBox.Show("Captcha Wrong", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Classes.Users user = new Classes.Users();
            user.Fullname = txbFullName.Text;
            user.Username = txbUsername.Text;
            user.Password = txbPassword.Text;
            user.Email = txbEmail.Text;
            user.Birthdate = dtpBirthdate.Value;
            user.Image = pictureBoxImage.Image;
            user.Status = Classes.Users.User_Status.Inactive;

            if (rbtnStudent.Checked)
                user.Role = Classes.Users.User_Role.Student;
            else if (rbtnTeacher.Checked)
                user.Role = Classes.Users.User_Role.Teacher;

            if (rbtnMale.Checked)
                user.Gender = "Male";
            else
                user.Gender = "Female";

            if (rbtnStudent.Checked)
                user.Code = DateTime.Now.ToString("yy") + "110" + Classes.TrungHelper.RandomString(3);
            else
                user.Code = "GV-" + Classes.TrungHelper.RandomString(3);

            if (user.isCheckUsernameExist())
            {
                txbUsername.BackColor = Color.Pink;
                MessageBox.Show("Username is exist. Please enter new username", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (user.isCheckEmailExist())
            {
                MessageBox.Show("Email is exist. Please enter new email", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (user.isInsert())
                MessageBox.Show("Register Account Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Register Fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool validateForm()
        {
            if (string.IsNullOrEmpty(txbUsername.Text) || string.IsNullOrEmpty(txbPassword.Text) || string.IsNullOrEmpty(txbEmail.Text)
                || string.IsNullOrEmpty(txbInputCaptcha.Text) || pictureBoxImage.Image == null
                || (!rbtnStudent.Checked && !rbtnTeacher.Checked)
                || string.IsNullOrEmpty(txbFullName.Text))
                return false;
            return true;
        }

        private void pictureBoxReloadCaptcha_Click(object sender, EventArgs e)
        {
            loadImageCaptcha();
        }
    }
}
