﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Users
{
    public partial class AddUsersForm : Form
    {
        public AddUsersForm()
        {
            InitializeComponent();
        }

        private void pictureBoxUploadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.png; *.jpeg; *.gif; *.bmp)|*.jpg; *.png; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBoxPreview.Image = new Bitmap(open.FileName);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!validateForm())
            {
                MessageBox.Show("Please Enter All Fields. Can not empty any fields", "Validate Form Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Classes.Users user = new Classes.Users();
            user.Email = txbEmail.Text;
            user.Username = txbUsername.Text;
            user.Password = txbPassword.Text;
            user.Fullname = txbFullName.Text;
            if (rbtnFemale.Checked)
                user.Gender = "Female";
            else
                user.Gender = "Male";
            user.Birthdate = dtpBirthdate.Value;
            user.Code = txbCode.Text;
            if (rbtnStudent.Checked)
                user.Role = Classes.Users.User_Role.Student;
            else if (rbtnTeacher.Checked)
                user.Role = Classes.Users.User_Role.Teacher;
            user.Image = pictureBoxPreview.Image;

            if (user.isCheckUsernameExist())
            {
                MessageBox.Show("Username is exist. Please enter new username", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if(user.isCheckCodeExist())
            {
                MessageBox.Show("Code is exist. Please enter new Code", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (user.isCheckEmailExist())
            {
                MessageBox.Show("Email is exist. Please enter new email", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (user.isInsert())
                MessageBox.Show("Add User Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Add User Fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private bool validateForm()
        {
            if (string.IsNullOrEmpty(txbFullName.Text) || string.IsNullOrEmpty(txbUsername.Text) || string.IsNullOrEmpty(txbPassword.Text)
                    || string.IsNullOrEmpty(txbCode.Text) || (!rbtnFemale.Checked && !rbtnMale.Checked) || (!rbtnStudent.Checked && !rbtnTeacher.Checked) 
                    || string.IsNullOrEmpty(txbEmail.Text))
                return false;
            return true;
        }

        private void rbtnTeacher_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnTeacher.Checked)
                txbCode.Text = "GV-";
            else
                txbCode.Text = string.Empty;
        }
    }
}
