﻿
namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Users
{
    partial class ViewUsersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewUsersForm));
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txbUsername = new System.Windows.Forms.TextBox();
            this.txbFullname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBoxPreview = new System.Windows.Forms.PictureBox();
            this.pictureBoxUploadImage = new System.Windows.Forms.PictureBox();
            this.panelInfoUser = new System.Windows.Forms.Panel();
            this.panelStatusRbtn = new System.Windows.Forms.Panel();
            this.rbtnStatusDisabled = new System.Windows.Forms.RadioButton();
            this.rbtnStatusInactive = new System.Windows.Forms.RadioButton();
            this.rbtnStatusActive = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.txbEmail = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txbCode = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpBirthdate = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.rbtnTeacher = new System.Windows.Forms.RadioButton();
            this.rbtnStudent = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.panelGenderRbtn = new System.Windows.Forms.Panel();
            this.rbtnFemale = new System.Windows.Forms.RadioButton();
            this.rbtnMale = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.txbPassword = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridViewListInfoUser = new System.Windows.Forms.DataGridView();
            this.panelDvBooks = new System.Windows.Forms.Panel();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.txbFullnameSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelSearch = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.pictureBoxTitle = new System.Windows.Forms.PictureBox();
            this.panelTitle = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPreview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUploadImage)).BeginInit();
            this.panelInfoUser.SuspendLayout();
            this.panelStatusRbtn.SuspendLayout();
            this.panelGenderRbtn.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListInfoUser)).BeginInit();
            this.panelDvBooks.SuspendLayout();
            this.panelSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).BeginInit();
            this.panelTitle.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(743, 340);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(105, 49);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(532, 340);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(105, 49);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(340, 340);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(105, 49);
            this.btnUpdate.TabIndex = 14;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txbUsername
            // 
            this.txbUsername.Location = new System.Drawing.Point(206, 90);
            this.txbUsername.Name = "txbUsername";
            this.txbUsername.Size = new System.Drawing.Size(364, 26);
            this.txbUsername.TabIndex = 1;
            // 
            // txbFullname
            // 
            this.txbFullname.Location = new System.Drawing.Point(206, 29);
            this.txbFullname.Name = "txbFullname";
            this.txbFullname.Size = new System.Drawing.Size(364, 26);
            this.txbFullname.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(85, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(85, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(85, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Full name";
            // 
            // pictureBoxPreview
            // 
            this.pictureBoxPreview.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBoxPreview.Location = new System.Drawing.Point(0, 193);
            this.pictureBoxPreview.Name = "pictureBoxPreview";
            this.pictureBoxPreview.Size = new System.Drawing.Size(309, 239);
            this.pictureBoxPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPreview.TabIndex = 12;
            this.pictureBoxPreview.TabStop = false;
            // 
            // pictureBoxUploadImage
            // 
            this.pictureBoxUploadImage.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBoxUploadImage.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxUploadImage.Image")));
            this.pictureBoxUploadImage.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxUploadImage.Name = "pictureBoxUploadImage";
            this.pictureBoxUploadImage.Size = new System.Drawing.Size(309, 141);
            this.pictureBoxUploadImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxUploadImage.TabIndex = 1;
            this.pictureBoxUploadImage.TabStop = false;
            this.pictureBoxUploadImage.Click += new System.EventHandler(this.pictureBoxUploadImage_Click);
            // 
            // panelInfoUser
            // 
            this.panelInfoUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panelInfoUser.Controls.Add(this.panelStatusRbtn);
            this.panelInfoUser.Controls.Add(this.label10);
            this.panelInfoUser.Controls.Add(this.txbEmail);
            this.panelInfoUser.Controls.Add(this.label9);
            this.panelInfoUser.Controls.Add(this.txbCode);
            this.panelInfoUser.Controls.Add(this.label7);
            this.panelInfoUser.Controls.Add(this.dtpBirthdate);
            this.panelInfoUser.Controls.Add(this.label6);
            this.panelInfoUser.Controls.Add(this.rbtnTeacher);
            this.panelInfoUser.Controls.Add(this.rbtnStudent);
            this.panelInfoUser.Controls.Add(this.label8);
            this.panelInfoUser.Controls.Add(this.panelGenderRbtn);
            this.panelInfoUser.Controls.Add(this.label5);
            this.panelInfoUser.Controls.Add(this.txbPassword);
            this.panelInfoUser.Controls.Add(this.panel1);
            this.panelInfoUser.Controls.Add(this.btnCancel);
            this.panelInfoUser.Controls.Add(this.btnDelete);
            this.panelInfoUser.Controls.Add(this.btnUpdate);
            this.panelInfoUser.Controls.Add(this.txbUsername);
            this.panelInfoUser.Controls.Add(this.txbFullname);
            this.panelInfoUser.Controls.Add(this.label4);
            this.panelInfoUser.Controls.Add(this.label3);
            this.panelInfoUser.Controls.Add(this.label2);
            this.panelInfoUser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInfoUser.Location = new System.Drawing.Point(0, 618);
            this.panelInfoUser.Name = "panelInfoUser";
            this.panelInfoUser.Size = new System.Drawing.Size(1710, 432);
            this.panelInfoUser.TabIndex = 7;
            // 
            // panelStatusRbtn
            // 
            this.panelStatusRbtn.Controls.Add(this.rbtnStatusDisabled);
            this.panelStatusRbtn.Controls.Add(this.rbtnStatusInactive);
            this.panelStatusRbtn.Controls.Add(this.rbtnStatusActive);
            this.panelStatusRbtn.Location = new System.Drawing.Point(855, 257);
            this.panelStatusRbtn.Name = "panelStatusRbtn";
            this.panelStatusRbtn.Size = new System.Drawing.Size(409, 63);
            this.panelStatusRbtn.TabIndex = 33;
            // 
            // rbtnStatusDisabled
            // 
            this.rbtnStatusDisabled.AutoSize = true;
            this.rbtnStatusDisabled.Location = new System.Drawing.Point(263, 19);
            this.rbtnStatusDisabled.Name = "rbtnStatusDisabled";
            this.rbtnStatusDisabled.Size = new System.Drawing.Size(96, 24);
            this.rbtnStatusDisabled.TabIndex = 2;
            this.rbtnStatusDisabled.TabStop = true;
            this.rbtnStatusDisabled.Text = "Disabled";
            this.rbtnStatusDisabled.UseVisualStyleBackColor = true;
            // 
            // rbtnStatusInactive
            // 
            this.rbtnStatusInactive.AutoSize = true;
            this.rbtnStatusInactive.Location = new System.Drawing.Point(118, 19);
            this.rbtnStatusInactive.Name = "rbtnStatusInactive";
            this.rbtnStatusInactive.Size = new System.Drawing.Size(89, 24);
            this.rbtnStatusInactive.TabIndex = 1;
            this.rbtnStatusInactive.TabStop = true;
            this.rbtnStatusInactive.Text = "Inactive";
            this.rbtnStatusInactive.UseVisualStyleBackColor = true;
            // 
            // rbtnStatusActive
            // 
            this.rbtnStatusActive.AutoSize = true;
            this.rbtnStatusActive.Location = new System.Drawing.Point(10, 19);
            this.rbtnStatusActive.Name = "rbtnStatusActive";
            this.rbtnStatusActive.Size = new System.Drawing.Size(77, 24);
            this.rbtnStatusActive.TabIndex = 0;
            this.rbtnStatusActive.TabStop = true;
            this.rbtnStatusActive.Text = "Active";
            this.rbtnStatusActive.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(657, 280);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 20);
            this.label10.TabIndex = 32;
            this.label10.Text = "Status";
            // 
            // txbEmail
            // 
            this.txbEmail.Location = new System.Drawing.Point(855, 158);
            this.txbEmail.Name = "txbEmail";
            this.txbEmail.ReadOnly = true;
            this.txbEmail.Size = new System.Drawing.Size(364, 26);
            this.txbEmail.TabIndex = 30;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(657, 158);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 20);
            this.label9.TabIndex = 31;
            this.label9.Text = "Email";
            // 
            // txbCode
            // 
            this.txbCode.Location = new System.Drawing.Point(855, 213);
            this.txbCode.Name = "txbCode";
            this.txbCode.ReadOnly = true;
            this.txbCode.Size = new System.Drawing.Size(364, 26);
            this.txbCode.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(657, 213);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 20);
            this.label7.TabIndex = 29;
            this.label7.Text = "Code";
            // 
            // dtpBirthdate
            // 
            this.dtpBirthdate.Location = new System.Drawing.Point(852, 29);
            this.dtpBirthdate.Name = "dtpBirthdate";
            this.dtpBirthdate.Size = new System.Drawing.Size(367, 26);
            this.dtpBirthdate.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(657, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 20);
            this.label6.TabIndex = 28;
            this.label6.Text = "Birthdate";
            // 
            // rbtnTeacher
            // 
            this.rbtnTeacher.AutoSize = true;
            this.rbtnTeacher.Location = new System.Drawing.Point(1040, 94);
            this.rbtnTeacher.Name = "rbtnTeacher";
            this.rbtnTeacher.Size = new System.Drawing.Size(92, 24);
            this.rbtnTeacher.TabIndex = 6;
            this.rbtnTeacher.TabStop = true;
            this.rbtnTeacher.Text = "Teacher";
            this.rbtnTeacher.UseVisualStyleBackColor = true;
            // 
            // rbtnStudent
            // 
            this.rbtnStudent.AutoSize = true;
            this.rbtnStudent.Location = new System.Drawing.Point(865, 94);
            this.rbtnStudent.Name = "rbtnStudent";
            this.rbtnStudent.Size = new System.Drawing.Size(91, 24);
            this.rbtnStudent.TabIndex = 5;
            this.rbtnStudent.TabStop = true;
            this.rbtnStudent.Text = "Student";
            this.rbtnStudent.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(657, 98);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 20);
            this.label8.TabIndex = 27;
            this.label8.Text = "User Role";
            // 
            // panelGenderRbtn
            // 
            this.panelGenderRbtn.Controls.Add(this.rbtnFemale);
            this.panelGenderRbtn.Controls.Add(this.rbtnMale);
            this.panelGenderRbtn.Location = new System.Drawing.Point(206, 213);
            this.panelGenderRbtn.Name = "panelGenderRbtn";
            this.panelGenderRbtn.Size = new System.Drawing.Size(366, 61);
            this.panelGenderRbtn.TabIndex = 3;
            // 
            // rbtnFemale
            // 
            this.rbtnFemale.AutoSize = true;
            this.rbtnFemale.Location = new System.Drawing.Point(188, 18);
            this.rbtnFemale.Name = "rbtnFemale";
            this.rbtnFemale.Size = new System.Drawing.Size(87, 24);
            this.rbtnFemale.TabIndex = 1;
            this.rbtnFemale.TabStop = true;
            this.rbtnFemale.Text = "Female";
            this.rbtnFemale.UseVisualStyleBackColor = true;
            // 
            // rbtnMale
            // 
            this.rbtnMale.AutoSize = true;
            this.rbtnMale.Location = new System.Drawing.Point(13, 20);
            this.rbtnMale.Name = "rbtnMale";
            this.rbtnMale.Size = new System.Drawing.Size(68, 24);
            this.rbtnMale.TabIndex = 0;
            this.rbtnMale.TabStop = true;
            this.rbtnMale.Text = "Male";
            this.rbtnMale.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(85, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "Gender";
            // 
            // txbPassword
            // 
            this.txbPassword.Location = new System.Drawing.Point(206, 152);
            this.txbPassword.Name = "txbPassword";
            this.txbPassword.Size = new System.Drawing.Size(364, 26);
            this.txbPassword.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBoxPreview);
            this.panel1.Controls.Add(this.pictureBoxUploadImage);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(1401, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(309, 432);
            this.panel1.TabIndex = 15;
            // 
            // dataGridViewListInfoUser
            // 
            this.dataGridViewListInfoUser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewListInfoUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewListInfoUser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewListInfoUser.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewListInfoUser.Name = "dataGridViewListInfoUser";
            this.dataGridViewListInfoUser.RowHeadersWidth = 62;
            this.dataGridViewListInfoUser.RowTemplate.Height = 28;
            this.dataGridViewListInfoUser.Size = new System.Drawing.Size(1710, 388);
            this.dataGridViewListInfoUser.TabIndex = 0;
            this.dataGridViewListInfoUser.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewListInfoUser_CellDoubleClick);
            // 
            // panelDvBooks
            // 
            this.panelDvBooks.Controls.Add(this.dataGridViewListInfoUser);
            this.panelDvBooks.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDvBooks.Location = new System.Drawing.Point(0, 230);
            this.panelDvBooks.Name = "panelDvBooks";
            this.panelDvBooks.Size = new System.Drawing.Size(1710, 388);
            this.panelDvBooks.TabIndex = 6;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(774, 30);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(126, 41);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // txbFullnameSearch
            // 
            this.txbFullnameSearch.Location = new System.Drawing.Point(482, 36);
            this.txbFullnameSearch.Name = "txbFullnameSearch";
            this.txbFullnameSearch.Size = new System.Drawing.Size(237, 26);
            this.txbFullnameSearch.TabIndex = 1;
            this.txbFullnameSearch.TextChanged += new System.EventHandler(this.txbFullnameSearch_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(274, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Full name, Email, Code";
            // 
            // panelSearch
            // 
            this.panelSearch.Controls.Add(this.btnRefresh);
            this.panelSearch.Controls.Add(this.txbFullnameSearch);
            this.panelSearch.Controls.Add(this.label1);
            this.panelSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSearch.Location = new System.Drawing.Point(0, 121);
            this.panelSearch.Name = "panelSearch";
            this.panelSearch.Size = new System.Drawing.Size(1710, 109);
            this.panelSearch.TabIndex = 5;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelTitle.Location = new System.Drawing.Point(618, 49);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(302, 29);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "Users View Management";
            // 
            // pictureBoxTitle
            // 
            this.pictureBoxTitle.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTitle.Image")));
            this.pictureBoxTitle.Location = new System.Drawing.Point(482, 12);
            this.pictureBoxTitle.Name = "pictureBoxTitle";
            this.pictureBoxTitle.Size = new System.Drawing.Size(88, 106);
            this.pictureBoxTitle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTitle.TabIndex = 0;
            this.pictureBoxTitle.TabStop = false;
            // 
            // panelTitle
            // 
            this.panelTitle.BackColor = System.Drawing.Color.White;
            this.panelTitle.Controls.Add(this.labelTitle);
            this.panelTitle.Controls.Add(this.pictureBoxTitle);
            this.panelTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitle.Location = new System.Drawing.Point(0, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(1710, 121);
            this.panelTitle.TabIndex = 4;
            // 
            // ViewUsersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1710, 1050);
            this.Controls.Add(this.panelInfoUser);
            this.Controls.Add(this.panelDvBooks);
            this.Controls.Add(this.panelSearch);
            this.Controls.Add(this.panelTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "ViewUsersForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewUsersForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ViewUsersForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPreview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUploadImage)).EndInit();
            this.panelInfoUser.ResumeLayout(false);
            this.panelInfoUser.PerformLayout();
            this.panelStatusRbtn.ResumeLayout(false);
            this.panelStatusRbtn.PerformLayout();
            this.panelGenderRbtn.ResumeLayout(false);
            this.panelGenderRbtn.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListInfoUser)).EndInit();
            this.panelDvBooks.ResumeLayout(false);
            this.panelSearch.ResumeLayout(false);
            this.panelSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).EndInit();
            this.panelTitle.ResumeLayout(false);
            this.panelTitle.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txbUsername;
        private System.Windows.Forms.TextBox txbFullname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBoxPreview;
        private System.Windows.Forms.PictureBox pictureBoxUploadImage;
        private System.Windows.Forms.Panel panelInfoUser;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridViewListInfoUser;
        private System.Windows.Forms.Panel panelDvBooks;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.TextBox txbFullnameSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelSearch;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.PictureBox pictureBoxTitle;
        private System.Windows.Forms.Panel panelTitle;
        private System.Windows.Forms.TextBox txbPassword;
        private System.Windows.Forms.Panel panelGenderRbtn;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.RadioButton rbtnMale;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbCode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpBirthdate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rbtnTeacher;
        private System.Windows.Forms.RadioButton rbtnStudent;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txbEmail;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panelStatusRbtn;
        private System.Windows.Forms.RadioButton rbtnStatusActive;
        private System.Windows.Forms.RadioButton rbtnStatusInactive;
        private System.Windows.Forms.RadioButton rbtnStatusDisabled;
    }
}