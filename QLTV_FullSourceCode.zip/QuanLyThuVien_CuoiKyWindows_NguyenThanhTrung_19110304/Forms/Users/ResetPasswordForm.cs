﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Users
{
    public partial class ResetPasswordForm : Form
    {
        private string userID = string.Empty;

        public ResetPasswordForm()
        {
            InitializeComponent();
        }

        private void btnSendEmail_Click(object sender, EventArgs e)
        {
            string email = txbEmail.Text;
            if(email.Split('@').Length != 2)
            {
                MessageBox.Show("Error input format Email", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            userID = Classes.Users.getUserIDFromEmail(email);
            if(string.IsNullOrEmpty(userID))
            {
                MessageBox.Show("Email is not exist", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if(!Classes.TrungHelper.boolSendEmailRecoverAccount(email, userID))
            {
                MessageBox.Show("Email system error now. Please comeback later!", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("We sent email recover account to your email!", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            btnSendEmail.Enabled = false;
            txbEmail.Enabled = false;

            txbCodeRecover.Enabled = true;
            btnCheckCode.Enabled = true;


        }

        private void btnCheckCode_Click(object sender, EventArgs e)
        {
            string code = txbCodeRecover.Text;
            bool isCodeAvailable = Classes.TrungHelper.isCheckCodeAvailable(code, userID);
            if(!isCodeAvailable)
            {
                MessageBox.Show("Code is not available", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            txbCodeRecover.Enabled = false;
            btnCheckCode.Enabled = false;

            txbNewPass.Enabled = true;
            btnChangePass.Enabled = true;
        }

        private void btnChangePass_Click(object sender, EventArgs e)
        {
            string newPass = txbNewPass.Text;

            if(string.IsNullOrEmpty(newPass))
            {
                MessageBox.Show("Password is not available", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool isUpdatePassword = Classes.Users.isUpdatePassword(userID, newPass);
            if(isUpdatePassword)
            {
                MessageBox.Show("Password is update success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }
    }
}
