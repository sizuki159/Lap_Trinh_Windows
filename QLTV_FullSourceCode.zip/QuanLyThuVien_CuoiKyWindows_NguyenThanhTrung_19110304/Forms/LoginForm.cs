﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes;
using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms;
using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Users;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txbUsername_MouseClick(object sender, MouseEventArgs e)
        {
            if (txbUsername.Text == "Username")
                txbUsername.Clear();
        }

        private void txbPassword_MouseClick(object sender, MouseEventArgs e)
        {
            if (txbPassword.Text == "Password")
            {
                txbPassword.Clear();
                txbPassword.PasswordChar = '*';
            }
        }

        private void pictureBoxFacebook_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/sizuki159");
        }

        private void pictureBoxMessenger_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.messenger.com/sizuki159");
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txbUsername.Text;
            string password = txbPassword.Text;

            Users objUser = new Users(username, password);

            bool isCheckLogin = objUser.isCheckLogin();
            
            //Login thông tin đúng
            if (isCheckLogin)
            {
                // Account Ban
                if (objUser.Status == Users.User_Status.Disabled)
                {
                    MessageBox.Show("Account Disabled");
                    return;
                }
                // Account InActive
                else if (objUser.Status == Users.User_Status.Inactive)
                {
                    MessageBox.Show("Your account inactive. Please contact Admin Library HCMUTE to active account");
                    return;
                }
                else
                {

                }

                // Lưu phiên và thông tin đăng nhập
                bool isUpdateSessionLogin = objUser.isUpdateSessionLogin();
                if (!isUpdateSessionLogin)
                {
                    MessageBox.Show("Set Info Session Login Fail!", "System Errors", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Thong bao login thanh cong va an form login
                //MessageBox.Show("Login Success, Click Ok to redirect Dashboard Form", "Login Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();


                // Kiểm tra xem có nằm trong thời gian mở cửa hay không , người dùng thường mới bị rèn buộc này

                if(objUser.Role != Users.User_Role.Admin)
                {
                    DateTime timeNow = DateTime.Now;
                    int hourOpen = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyHourOpen));
                    int hourClose = Convert.ToInt32(Classes.Settings.getValue(Classes.Settings.KeyHourClose));
                    if (timeNow.Hour < hourOpen || timeNow.Hour > hourClose)
                    {
                        MessageBox.Show("The library is closed. Please come back later", "System Closed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        Application.Exit();
                        return;
                    }
                }
                DashboardForm dashboardForm = new DashboardForm();
                dashboardForm.Show();
                
            }
            // Login Fail
            else
            {
                MessageBox.Show("Username or Password Not Exist", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            RegisterForm register = new RegisterForm();
            register.ShowDialog();


            //string username = txbUsername.Text;
            //string password = txbPassword.Text;

            //Users objUser = new Users(username, password);
            //if(objUser.isCheckUsernameExist())
            //{
            //    MessageBox.Show("Username already exist", "Signup Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}
            //else
            //{

            //}

        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            txbUsername.Text = "thanhtrung";
            txbPassword.Text = "thanhtrung";
            txbPassword.PasswordChar = '*';
        }

        
        private void linkLabelForgotPass_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ResetPasswordForm resetPasswordForm = new ResetPasswordForm();
            resetPasswordForm.ShowDialog();
        }
    }
}
