﻿
namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Books
{
    partial class AddBookTypeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddBookTypeForm));
            this.rbtnStatusInactive = new System.Windows.Forms.RadioButton();
            this.rbtnStatusActive = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.pictureBoxTitle = new System.Windows.Forms.PictureBox();
            this.txbName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.labelTitle = new System.Windows.Forms.Label();
            this.panelRight = new System.Windows.Forms.Panel();
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.dataGridViewListBookType = new System.Windows.Forms.DataGridView();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.panelContentDelete = new System.Windows.Forms.Panel();
            this.labelShowNotification = new System.Windows.Forms.Label();
            this.btnConfirmDelete = new System.Windows.Forms.Button();
            this.rbtnDeleteAllBook = new System.Windows.Forms.RadioButton();
            this.rbtnChangeBookType = new System.Windows.Forms.RadioButton();
            this.comboBoxType = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).BeginInit();
            this.panelRight.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.panelLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListBookType)).BeginInit();
            this.panelContentDelete.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbtnStatusInactive
            // 
            this.rbtnStatusInactive.AutoSize = true;
            this.rbtnStatusInactive.Location = new System.Drawing.Point(249, 76);
            this.rbtnStatusInactive.Name = "rbtnStatusInactive";
            this.rbtnStatusInactive.Size = new System.Drawing.Size(89, 24);
            this.rbtnStatusInactive.TabIndex = 14;
            this.rbtnStatusInactive.TabStop = true;
            this.rbtnStatusInactive.Text = "Inactive";
            this.rbtnStatusInactive.UseVisualStyleBackColor = true;
            // 
            // rbtnStatusActive
            // 
            this.rbtnStatusActive.AutoSize = true;
            this.rbtnStatusActive.Location = new System.Drawing.Point(113, 76);
            this.rbtnStatusActive.Name = "rbtnStatusActive";
            this.rbtnStatusActive.Size = new System.Drawing.Size(77, 24);
            this.rbtnStatusActive.TabIndex = 13;
            this.rbtnStatusActive.TabStop = true;
            this.rbtnStatusActive.Text = "Active";
            this.rbtnStatusActive.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Status";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(73, 146);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(125, 43);
            this.btnAdd.TabIndex = 11;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // pictureBoxTitle
            // 
            this.pictureBoxTitle.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTitle.Image")));
            this.pictureBoxTitle.Location = new System.Drawing.Point(401, 0);
            this.pictureBoxTitle.Name = "pictureBoxTitle";
            this.pictureBoxTitle.Size = new System.Drawing.Size(59, 53);
            this.pictureBoxTitle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTitle.TabIndex = 0;
            this.pictureBoxTitle.TabStop = false;
            // 
            // txbName
            // 
            this.txbName.Location = new System.Drawing.Point(114, 18);
            this.txbName.Name = "txbName";
            this.txbName.Size = new System.Drawing.Size(331, 26);
            this.txbName.TabIndex = 7;
            this.txbName.TextChanged += new System.EventHandler(this.txbName_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(490, 9);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(296, 29);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "Management Book Type";
            // 
            // panelRight
            // 
            this.panelRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panelRight.Controls.Add(this.panelContentDelete);
            this.panelRight.Controls.Add(this.btnRemove);
            this.panelRight.Controls.Add(this.btnUpdate);
            this.panelRight.Controls.Add(this.rbtnStatusInactive);
            this.panelRight.Controls.Add(this.rbtnStatusActive);
            this.panelRight.Controls.Add(this.label3);
            this.panelRight.Controls.Add(this.btnAdd);
            this.panelRight.Controls.Add(this.txbName);
            this.panelRight.Controls.Add(this.label1);
            this.panelRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelRight.Location = new System.Drawing.Point(836, 65);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(488, 902);
            this.panelRight.TabIndex = 5;
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.Wheat;
            this.panelTop.Controls.Add(this.labelTitle);
            this.panelTop.Controls.Add(this.pictureBoxTitle);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1324, 65);
            this.panelTop.TabIndex = 4;
            // 
            // panelLeft
            // 
            this.panelLeft.Controls.Add(this.dataGridViewListBookType);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 65);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(819, 902);
            this.panelLeft.TabIndex = 6;
            // 
            // dataGridViewListBookType
            // 
            this.dataGridViewListBookType.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewListBookType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewListBookType.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewListBookType.Name = "dataGridViewListBookType";
            this.dataGridViewListBookType.RowHeadersWidth = 62;
            this.dataGridViewListBookType.RowTemplate.Height = 28;
            this.dataGridViewListBookType.Size = new System.Drawing.Size(819, 902);
            this.dataGridViewListBookType.TabIndex = 0;
            this.dataGridViewListBookType.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewListBookType_CellDoubleClick);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(292, 146);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(125, 43);
            this.btnUpdate.TabIndex = 15;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(180, 223);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(125, 43);
            this.btnRemove.TabIndex = 16;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // panelContentDelete
            // 
            this.panelContentDelete.Controls.Add(this.comboBoxType);
            this.panelContentDelete.Controls.Add(this.rbtnChangeBookType);
            this.panelContentDelete.Controls.Add(this.rbtnDeleteAllBook);
            this.panelContentDelete.Controls.Add(this.btnConfirmDelete);
            this.panelContentDelete.Controls.Add(this.labelShowNotification);
            this.panelContentDelete.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelContentDelete.Location = new System.Drawing.Point(0, 556);
            this.panelContentDelete.Name = "panelContentDelete";
            this.panelContentDelete.Size = new System.Drawing.Size(488, 346);
            this.panelContentDelete.TabIndex = 17;
            // 
            // labelShowNotification
            // 
            this.labelShowNotification.AutoSize = true;
            this.labelShowNotification.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelShowNotification.ForeColor = System.Drawing.Color.Red;
            this.labelShowNotification.Location = new System.Drawing.Point(87, 29);
            this.labelShowNotification.Name = "labelShowNotification";
            this.labelShowNotification.Size = new System.Drawing.Size(331, 75);
            this.labelShowNotification.TabIndex = 0;
            this.labelShowNotification.Text = "Có xxx cuốn sách có loại sách\r\nbạn chuẩn bị xóa.\r\nBạn có chắc chắn muốn tiếp tục?" +
    "";
            // 
            // btnConfirmDelete
            // 
            this.btnConfirmDelete.Location = new System.Drawing.Point(149, 264);
            this.btnConfirmDelete.Name = "btnConfirmDelete";
            this.btnConfirmDelete.Size = new System.Drawing.Size(152, 46);
            this.btnConfirmDelete.TabIndex = 1;
            this.btnConfirmDelete.Text = "Confirm Delete";
            this.btnConfirmDelete.UseVisualStyleBackColor = true;
            this.btnConfirmDelete.Click += new System.EventHandler(this.btnConfirmDelete_Click);
            // 
            // rbtnDeleteAllBook
            // 
            this.rbtnDeleteAllBook.AutoSize = true;
            this.rbtnDeleteAllBook.Location = new System.Drawing.Point(36, 156);
            this.rbtnDeleteAllBook.Name = "rbtnDeleteAllBook";
            this.rbtnDeleteAllBook.Size = new System.Drawing.Size(143, 24);
            this.rbtnDeleteAllBook.TabIndex = 2;
            this.rbtnDeleteAllBook.TabStop = true;
            this.rbtnDeleteAllBook.Text = "Delete All Book";
            this.rbtnDeleteAllBook.UseVisualStyleBackColor = true;
            this.rbtnDeleteAllBook.CheckedChanged += new System.EventHandler(this.rbtnDeleteAllBook_CheckedChanged);
            // 
            // rbtnChangeBookType
            // 
            this.rbtnChangeBookType.AutoSize = true;
            this.rbtnChangeBookType.Location = new System.Drawing.Point(38, 194);
            this.rbtnChangeBookType.Name = "rbtnChangeBookType";
            this.rbtnChangeBookType.Size = new System.Drawing.Size(169, 24);
            this.rbtnChangeBookType.TabIndex = 3;
            this.rbtnChangeBookType.TabStop = true;
            this.rbtnChangeBookType.Text = "Change Book Type";
            this.rbtnChangeBookType.UseVisualStyleBackColor = true;
            // 
            // comboBoxType
            // 
            this.comboBoxType.FormattingEnabled = true;
            this.comboBoxType.Location = new System.Drawing.Point(213, 190);
            this.comboBoxType.Name = "comboBoxType";
            this.comboBoxType.Size = new System.Drawing.Size(263, 28);
            this.comboBoxType.TabIndex = 9;
            // 
            // AddBookTypeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1324, 967);
            this.Controls.Add(this.panelLeft);
            this.Controls.Add(this.panelRight);
            this.Controls.Add(this.panelTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "AddBookTypeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddBookTypeForm";
            this.Load += new System.EventHandler(this.AddBookTypeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).EndInit();
            this.panelRight.ResumeLayout(false);
            this.panelRight.PerformLayout();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelLeft.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListBookType)).EndInit();
            this.panelContentDelete.ResumeLayout(false);
            this.panelContentDelete.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RadioButton rbtnStatusInactive;
        private System.Windows.Forms.RadioButton rbtnStatusActive;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.PictureBox pictureBoxTitle;
        private System.Windows.Forms.TextBox txbName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.DataGridView dataGridViewListBookType;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Panel panelContentDelete;
        private System.Windows.Forms.Label labelShowNotification;
        private System.Windows.Forms.Button btnConfirmDelete;
        private System.Windows.Forms.RadioButton rbtnDeleteAllBook;
        private System.Windows.Forms.RadioButton rbtnChangeBookType;
        private System.Windows.Forms.ComboBox comboBoxType;
    }
}