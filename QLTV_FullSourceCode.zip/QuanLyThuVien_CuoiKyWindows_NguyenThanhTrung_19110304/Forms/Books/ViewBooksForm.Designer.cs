﻿
namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.Books
{
    partial class ViewBooksForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewBooksForm));
            this.panelTitle = new System.Windows.Forms.Panel();
            this.labelTitle = new System.Windows.Forms.Label();
            this.pictureBoxTitle = new System.Windows.Forms.PictureBox();
            this.panelSearch = new System.Windows.Forms.Panel();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.txbBookName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelDvBooks = new System.Windows.Forms.Panel();
            this.dataGridViewListInfoBook = new System.Windows.Forms.DataGridView();
            this.panelInfoBook = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.rbtnStatusPending = new System.Windows.Forms.RadioButton();
            this.rbtnStatusHiden = new System.Windows.Forms.RadioButton();
            this.rbtnStatusActive = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBoxBookPreview = new System.Windows.Forms.PictureBox();
            this.pictureBoxUploadImage = new System.Windows.Forms.PictureBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.rtbDescription = new System.Windows.Forms.RichTextBox();
            this.nrudQuantity = new System.Windows.Forms.NumericUpDown();
            this.nrudPrice = new System.Windows.Forms.NumericUpDown();
            this.txbAuthorName = new System.Windows.Forms.TextBox();
            this.comboBoxType = new System.Windows.Forms.ComboBox();
            this.txbName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).BeginInit();
            this.panelSearch.SuspendLayout();
            this.panelDvBooks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListInfoBook)).BeginInit();
            this.panelInfoBook.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBookPreview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUploadImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nrudQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nrudPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTitle
            // 
            this.panelTitle.BackColor = System.Drawing.Color.White;
            this.panelTitle.Controls.Add(this.labelTitle);
            this.panelTitle.Controls.Add(this.pictureBoxTitle);
            this.panelTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTitle.Location = new System.Drawing.Point(0, 0);
            this.panelTitle.Name = "panelTitle";
            this.panelTitle.Size = new System.Drawing.Size(1710, 121);
            this.panelTitle.TabIndex = 0;
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelTitle.Location = new System.Drawing.Point(618, 49);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(294, 29);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "Book View Management";
            // 
            // pictureBoxTitle
            // 
            this.pictureBoxTitle.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTitle.Image")));
            this.pictureBoxTitle.Location = new System.Drawing.Point(482, 12);
            this.pictureBoxTitle.Name = "pictureBoxTitle";
            this.pictureBoxTitle.Size = new System.Drawing.Size(88, 106);
            this.pictureBoxTitle.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxTitle.TabIndex = 0;
            this.pictureBoxTitle.TabStop = false;
            // 
            // panelSearch
            // 
            this.panelSearch.Controls.Add(this.btnRefresh);
            this.panelSearch.Controls.Add(this.txbBookName);
            this.panelSearch.Controls.Add(this.label1);
            this.panelSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSearch.Location = new System.Drawing.Point(0, 121);
            this.panelSearch.Name = "panelSearch";
            this.panelSearch.Size = new System.Drawing.Size(1710, 109);
            this.panelSearch.TabIndex = 1;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(929, 35);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(141, 41);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // txbBookName
            // 
            this.txbBookName.Location = new System.Drawing.Point(482, 45);
            this.txbBookName.Name = "txbBookName";
            this.txbBookName.Size = new System.Drawing.Size(410, 26);
            this.txbBookName.TabIndex = 1;
            this.txbBookName.TextChanged += new System.EventHandler(this.txbBookName_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(255, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Book, Author, Type Name";
            // 
            // panelDvBooks
            // 
            this.panelDvBooks.Controls.Add(this.dataGridViewListInfoBook);
            this.panelDvBooks.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDvBooks.Location = new System.Drawing.Point(0, 230);
            this.panelDvBooks.Name = "panelDvBooks";
            this.panelDvBooks.Size = new System.Drawing.Size(1710, 388);
            this.panelDvBooks.TabIndex = 2;
            // 
            // dataGridViewListInfoBook
            // 
            this.dataGridViewListInfoBook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewListInfoBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewListInfoBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewListInfoBook.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewListInfoBook.Name = "dataGridViewListInfoBook";
            this.dataGridViewListInfoBook.RowHeadersWidth = 62;
            this.dataGridViewListInfoBook.RowTemplate.Height = 28;
            this.dataGridViewListInfoBook.Size = new System.Drawing.Size(1710, 388);
            this.dataGridViewListInfoBook.TabIndex = 0;
            this.dataGridViewListInfoBook.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewListInfoBook_CellDoubleClick);
            // 
            // panelInfoBook
            // 
            this.panelInfoBook.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panelInfoBook.Controls.Add(this.label8);
            this.panelInfoBook.Controls.Add(this.rbtnStatusPending);
            this.panelInfoBook.Controls.Add(this.rbtnStatusHiden);
            this.panelInfoBook.Controls.Add(this.rbtnStatusActive);
            this.panelInfoBook.Controls.Add(this.panel1);
            this.panelInfoBook.Controls.Add(this.btnCancel);
            this.panelInfoBook.Controls.Add(this.btnDelete);
            this.panelInfoBook.Controls.Add(this.btnUpdate);
            this.panelInfoBook.Controls.Add(this.rtbDescription);
            this.panelInfoBook.Controls.Add(this.nrudQuantity);
            this.panelInfoBook.Controls.Add(this.nrudPrice);
            this.panelInfoBook.Controls.Add(this.txbAuthorName);
            this.panelInfoBook.Controls.Add(this.comboBoxType);
            this.panelInfoBook.Controls.Add(this.txbName);
            this.panelInfoBook.Controls.Add(this.label7);
            this.panelInfoBook.Controls.Add(this.label6);
            this.panelInfoBook.Controls.Add(this.label5);
            this.panelInfoBook.Controls.Add(this.label4);
            this.panelInfoBook.Controls.Add(this.label3);
            this.panelInfoBook.Controls.Add(this.label2);
            this.panelInfoBook.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInfoBook.Location = new System.Drawing.Point(0, 618);
            this.panelInfoBook.Name = "panelInfoBook";
            this.panelInfoBook.Size = new System.Drawing.Size(1710, 432);
            this.panelInfoBook.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(85, 238);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 20);
            this.label8.TabIndex = 19;
            this.label8.Text = "Status";
            // 
            // rbtnStatusPending
            // 
            this.rbtnStatusPending.AutoSize = true;
            this.rbtnStatusPending.Location = new System.Drawing.Point(431, 238);
            this.rbtnStatusPending.Name = "rbtnStatusPending";
            this.rbtnStatusPending.Size = new System.Drawing.Size(92, 24);
            this.rbtnStatusPending.TabIndex = 18;
            this.rbtnStatusPending.TabStop = true;
            this.rbtnStatusPending.Text = "Pending";
            this.rbtnStatusPending.UseVisualStyleBackColor = true;
            // 
            // rbtnStatusHiden
            // 
            this.rbtnStatusHiden.AutoSize = true;
            this.rbtnStatusHiden.Location = new System.Drawing.Point(319, 238);
            this.rbtnStatusHiden.Name = "rbtnStatusHiden";
            this.rbtnStatusHiden.Size = new System.Drawing.Size(76, 24);
            this.rbtnStatusHiden.TabIndex = 17;
            this.rbtnStatusHiden.TabStop = true;
            this.rbtnStatusHiden.Text = "Hiden";
            this.rbtnStatusHiden.UseVisualStyleBackColor = true;
            // 
            // rbtnStatusActive
            // 
            this.rbtnStatusActive.AutoSize = true;
            this.rbtnStatusActive.Location = new System.Drawing.Point(206, 238);
            this.rbtnStatusActive.Name = "rbtnStatusActive";
            this.rbtnStatusActive.Size = new System.Drawing.Size(77, 24);
            this.rbtnStatusActive.TabIndex = 16;
            this.rbtnStatusActive.TabStop = true;
            this.rbtnStatusActive.Text = "Active";
            this.rbtnStatusActive.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBoxBookPreview);
            this.panel1.Controls.Add(this.pictureBoxUploadImage);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(1401, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(309, 432);
            this.panel1.TabIndex = 15;
            // 
            // pictureBoxBookPreview
            // 
            this.pictureBoxBookPreview.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBoxBookPreview.Location = new System.Drawing.Point(0, 193);
            this.pictureBoxBookPreview.Name = "pictureBoxBookPreview";
            this.pictureBoxBookPreview.Size = new System.Drawing.Size(309, 239);
            this.pictureBoxBookPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBookPreview.TabIndex = 12;
            this.pictureBoxBookPreview.TabStop = false;
            // 
            // pictureBoxUploadImage
            // 
            this.pictureBoxUploadImage.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBoxUploadImage.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxUploadImage.Image")));
            this.pictureBoxUploadImage.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxUploadImage.Name = "pictureBoxUploadImage";
            this.pictureBoxUploadImage.Size = new System.Drawing.Size(309, 141);
            this.pictureBoxUploadImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxUploadImage.TabIndex = 1;
            this.pictureBoxUploadImage.TabStop = false;
            this.pictureBoxUploadImage.Click += new System.EventHandler(this.pictureBoxUploadImage_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(743, 308);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(105, 49);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(532, 308);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(105, 49);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(340, 308);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(105, 49);
            this.btnUpdate.TabIndex = 14;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // rtbDescription
            // 
            this.rtbDescription.Location = new System.Drawing.Point(810, 134);
            this.rtbDescription.Name = "rtbDescription";
            this.rtbDescription.Size = new System.Drawing.Size(400, 128);
            this.rtbDescription.TabIndex = 13;
            this.rtbDescription.Text = "";
            // 
            // nrudQuantity
            // 
            this.nrudQuantity.Location = new System.Drawing.Point(810, 90);
            this.nrudQuantity.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nrudQuantity.Name = "nrudQuantity";
            this.nrudQuantity.Size = new System.Drawing.Size(190, 26);
            this.nrudQuantity.TabIndex = 12;
            this.nrudQuantity.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nrudPrice
            // 
            this.nrudPrice.Location = new System.Drawing.Point(810, 29);
            this.nrudPrice.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nrudPrice.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nrudPrice.Name = "nrudPrice";
            this.nrudPrice.Size = new System.Drawing.Size(190, 26);
            this.nrudPrice.TabIndex = 11;
            this.nrudPrice.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // txbAuthorName
            // 
            this.txbAuthorName.Location = new System.Drawing.Point(206, 90);
            this.txbAuthorName.Name = "txbAuthorName";
            this.txbAuthorName.Size = new System.Drawing.Size(364, 26);
            this.txbAuthorName.TabIndex = 10;
            // 
            // comboBoxType
            // 
            this.comboBoxType.FormattingEnabled = true;
            this.comboBoxType.Location = new System.Drawing.Point(206, 150);
            this.comboBoxType.Name = "comboBoxType";
            this.comboBoxType.Size = new System.Drawing.Size(190, 28);
            this.comboBoxType.TabIndex = 9;
            // 
            // txbName
            // 
            this.txbName.Location = new System.Drawing.Point(206, 29);
            this.txbName.Name = "txbName";
            this.txbName.Size = new System.Drawing.Size(364, 26);
            this.txbName.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(672, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Book Description";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(672, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Book Quantity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(672, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Book Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(85, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Book Type";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(85, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Author Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Book Name";
            // 
            // ViewBooksForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1710, 1050);
            this.Controls.Add(this.panelInfoBook);
            this.Controls.Add(this.panelDvBooks);
            this.Controls.Add(this.panelSearch);
            this.Controls.Add(this.panelTitle);
            this.Name = "ViewBooksForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewBooksForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ViewBooksForm_Load);
            this.panelTitle.ResumeLayout(false);
            this.panelTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTitle)).EndInit();
            this.panelSearch.ResumeLayout(false);
            this.panelSearch.PerformLayout();
            this.panelDvBooks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListInfoBook)).EndInit();
            this.panelInfoBook.ResumeLayout(false);
            this.panelInfoBook.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBookPreview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUploadImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nrudQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nrudPrice)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTitle;
        private System.Windows.Forms.PictureBox pictureBoxTitle;
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Panel panelSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbBookName;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Panel panelDvBooks;
        private System.Windows.Forms.DataGridView dataGridViewListInfoBook;
        private System.Windows.Forms.Panel panelInfoBook;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txbName;
        private System.Windows.Forms.ComboBox comboBoxType;
        private System.Windows.Forms.TextBox txbAuthorName;
        private System.Windows.Forms.NumericUpDown nrudPrice;
        private System.Windows.Forms.NumericUpDown nrudQuantity;
        private System.Windows.Forms.RichTextBox rtbDescription;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBoxUploadImage;
        private System.Windows.Forms.PictureBox pictureBoxBookPreview;
        private System.Windows.Forms.RadioButton rbtnStatusPending;
        private System.Windows.Forms.RadioButton rbtnStatusHiden;
        private System.Windows.Forms.RadioButton rbtnStatusActive;
        private System.Windows.Forms.Label label8;
    }
}