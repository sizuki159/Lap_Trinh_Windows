﻿
namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.booksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.issueBooksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lendsBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lendBookToLibraryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myListBookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbUsername = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbTotalCategories = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbTotalBooks = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbTotalUsers = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panelUsers = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lbTotalStudent = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbTotalTeacher = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbTotalBorrow = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panelEmployee = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lbTotalArranger = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lbTotalDelivery = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lbTotalManager = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.lb10 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lbTotalEmployee = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panelBooks = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.lbBook5 = new System.Windows.Forms.Label();
            this.lbBook4 = new System.Windows.Forms.Label();
            this.lbBook3 = new System.Windows.Forms.Label();
            this.lbBook2 = new System.Windows.Forms.Label();
            this.lbBook1 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.lbTotalBookReturned = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.lbTotalBorrowing = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panelFooter = new System.Windows.Forms.Panel();
            this.lbFooter = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panelUsers.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panelEmployee.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panelBooks.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.panelFooter.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Wheat;
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.booksToolStripMenuItem,
            this.usersToolStripMenuItem,
            this.issueBooksToolStripMenuItem,
            this.historyToolStripMenuItem,
            this.exitToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.myAccountToolStripMenuItem,
            this.lendsBookToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1932, 74);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // booksToolStripMenuItem
            // 
            this.booksToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewBookToolStripMenuItem,
            this.viewBookToolStripMenuItem,
            this.bookTypeToolStripMenuItem});
            this.booksToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("booksToolStripMenuItem.Image")));
            this.booksToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.booksToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.White;
            this.booksToolStripMenuItem.Name = "booksToolStripMenuItem";
            this.booksToolStripMenuItem.Size = new System.Drawing.Size(186, 68);
            this.booksToolStripMenuItem.Text = "Manage Books";
            // 
            // addNewBookToolStripMenuItem
            // 
            this.addNewBookToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("addNewBookToolStripMenuItem.Image")));
            this.addNewBookToolStripMenuItem.Name = "addNewBookToolStripMenuItem";
            this.addNewBookToolStripMenuItem.Size = new System.Drawing.Size(232, 34);
            this.addNewBookToolStripMenuItem.Text = "Add new book";
            this.addNewBookToolStripMenuItem.Click += new System.EventHandler(this.addNewBookToolStripMenuItem_Click);
            // 
            // viewBookToolStripMenuItem
            // 
            this.viewBookToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("viewBookToolStripMenuItem.Image")));
            this.viewBookToolStripMenuItem.Name = "viewBookToolStripMenuItem";
            this.viewBookToolStripMenuItem.Size = new System.Drawing.Size(232, 34);
            this.viewBookToolStripMenuItem.Text = "View Book";
            this.viewBookToolStripMenuItem.Click += new System.EventHandler(this.viewBookToolStripMenuItem_Click);
            // 
            // bookTypeToolStripMenuItem
            // 
            this.bookTypeToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("bookTypeToolStripMenuItem.Image")));
            this.bookTypeToolStripMenuItem.Name = "bookTypeToolStripMenuItem";
            this.bookTypeToolStripMenuItem.Size = new System.Drawing.Size(232, 34);
            this.bookTypeToolStripMenuItem.Text = "Book Type";
            this.bookTypeToolStripMenuItem.Click += new System.EventHandler(this.bookTypeToolStripMenuItem_Click);
            // 
            // usersToolStripMenuItem
            // 
            this.usersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addUserToolStripMenuItem,
            this.viewUserToolStripMenuItem});
            this.usersToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("usersToolStripMenuItem.Image")));
            this.usersToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.usersToolStripMenuItem.Name = "usersToolStripMenuItem";
            this.usersToolStripMenuItem.Size = new System.Drawing.Size(188, 68);
            this.usersToolStripMenuItem.Text = "Manage Users";
            // 
            // addUserToolStripMenuItem
            // 
            this.addUserToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("addUserToolStripMenuItem.Image")));
            this.addUserToolStripMenuItem.Name = "addUserToolStripMenuItem";
            this.addUserToolStripMenuItem.Size = new System.Drawing.Size(197, 34);
            this.addUserToolStripMenuItem.Text = "Add user";
            this.addUserToolStripMenuItem.Click += new System.EventHandler(this.addUserToolStripMenuItem_Click);
            // 
            // viewUserToolStripMenuItem
            // 
            this.viewUserToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("viewUserToolStripMenuItem.Image")));
            this.viewUserToolStripMenuItem.Name = "viewUserToolStripMenuItem";
            this.viewUserToolStripMenuItem.Size = new System.Drawing.Size(197, 34);
            this.viewUserToolStripMenuItem.Text = "View users";
            this.viewUserToolStripMenuItem.Click += new System.EventHandler(this.viewUserToolStripMenuItem_Click);
            // 
            // issueBooksToolStripMenuItem
            // 
            this.issueBooksToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("issueBooksToolStripMenuItem.Image")));
            this.issueBooksToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.issueBooksToolStripMenuItem.Name = "issueBooksToolStripMenuItem";
            this.issueBooksToolStripMenuItem.Size = new System.Drawing.Size(175, 68);
            this.issueBooksToolStripMenuItem.Text = "Menu Books";
            this.issueBooksToolStripMenuItem.Click += new System.EventHandler(this.issueBooksToolStripMenuItem_Click);
            // 
            // historyToolStripMenuItem
            // 
            this.historyToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("historyToolStripMenuItem.Image")));
            this.historyToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.historyToolStripMenuItem.Name = "historyToolStripMenuItem";
            this.historyToolStripMenuItem.Size = new System.Drawing.Size(149, 68);
            this.historyToolStripMenuItem.Text = "History";
            this.historyToolStripMenuItem.Click += new System.EventHandler(this.historyToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitToolStripMenuItem.Image")));
            this.exitToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 68);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.settingsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("settingsToolStripMenuItem.Image")));
            this.settingsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(140, 68);
            this.settingsToolStripMenuItem.Text = "Settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // myAccountToolStripMenuItem
            // 
            this.myAccountToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("myAccountToolStripMenuItem.Image")));
            this.myAccountToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.myAccountToolStripMenuItem.Name = "myAccountToolStripMenuItem";
            this.myAccountToolStripMenuItem.Size = new System.Drawing.Size(153, 68);
            this.myAccountToolStripMenuItem.Text = "My Account";
            this.myAccountToolStripMenuItem.Click += new System.EventHandler(this.myAccountToolStripMenuItem_Click);
            // 
            // lendsBookToolStripMenuItem
            // 
            this.lendsBookToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.lendsBookToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lendBookToLibraryToolStripMenuItem,
            this.myListBookToolStripMenuItem});
            this.lendsBookToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("lendsBookToolStripMenuItem.Image")));
            this.lendsBookToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.lendsBookToolStripMenuItem.Name = "lendsBookToolStripMenuItem";
            this.lendsBookToolStripMenuItem.Size = new System.Drawing.Size(168, 68);
            this.lendsBookToolStripMenuItem.Text = "Lends Book";
            // 
            // lendBookToLibraryToolStripMenuItem
            // 
            this.lendBookToLibraryToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("lendBookToLibraryToolStripMenuItem.Image")));
            this.lendBookToLibraryToolStripMenuItem.Name = "lendBookToLibraryToolStripMenuItem";
            this.lendBookToLibraryToolStripMenuItem.Size = new System.Drawing.Size(278, 34);
            this.lendBookToLibraryToolStripMenuItem.Text = "Lend Book to Library";
            this.lendBookToLibraryToolStripMenuItem.Click += new System.EventHandler(this.lendBookToLibraryToolStripMenuItem_Click);
            // 
            // myListBookToolStripMenuItem
            // 
            this.myListBookToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("myListBookToolStripMenuItem.Image")));
            this.myListBookToolStripMenuItem.Name = "myListBookToolStripMenuItem";
            this.myListBookToolStripMenuItem.Size = new System.Drawing.Size(278, 34);
            this.myListBookToolStripMenuItem.Text = "My List Book";
            this.myListBookToolStripMenuItem.Click += new System.EventHandler(this.myListBookToolStripMenuItem_Click);
            // 
            // lbUsername
            // 
            this.lbUsername.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbUsername.AutoSize = true;
            this.lbUsername.BackColor = System.Drawing.Color.Wheat;
            this.lbUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUsername.ForeColor = System.Drawing.Color.Red;
            this.lbUsername.Location = new System.Drawing.Point(1335, 22);
            this.lbUsername.Name = "lbUsername";
            this.lbUsername.Size = new System.Drawing.Size(132, 29);
            this.lbUsername.TabIndex = 1;
            this.lbUsername.Text = "Username";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(642, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(519, 40);
            this.label1.TabIndex = 3;
            this.label1.Text = "Thống kê người dùng thư viện";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(54)))), ((int)(((byte)(226)))));
            this.panel1.Controls.Add(this.lbTotalCategories);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(47, 95);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(365, 100);
            this.panel1.TabIndex = 4;
            // 
            // lbTotalCategories
            // 
            this.lbTotalCategories.AutoSize = true;
            this.lbTotalCategories.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalCategories.ForeColor = System.Drawing.Color.White;
            this.lbTotalCategories.Location = new System.Drawing.Point(198, 52);
            this.lbTotalCategories.Name = "lbTotalCategories";
            this.lbTotalCategories.Size = new System.Drawing.Size(72, 37);
            this.lbTotalCategories.TabIndex = 6;
            this.lbTotalCategories.Text = "123";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 74);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(112, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(202, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Tổng số Categories";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(54)))), ((int)(((byte)(226)))));
            this.panel2.Controls.Add(this.lbTotalBooks);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(453, 95);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(292, 100);
            this.panel2.TabIndex = 7;
            // 
            // lbTotalBooks
            // 
            this.lbTotalBooks.AutoSize = true;
            this.lbTotalBooks.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalBooks.ForeColor = System.Drawing.Color.White;
            this.lbTotalBooks.Location = new System.Drawing.Point(154, 50);
            this.lbTotalBooks.Name = "lbTotalBooks";
            this.lbTotalBooks.Size = new System.Drawing.Size(72, 37);
            this.lbTotalBooks.TabIndex = 6;
            this.lbTotalBooks.Text = "123";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 13);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(111, 77);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(119, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 25);
            this.label4.TabIndex = 5;
            this.label4.Text = "Tổng số sách";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Olive;
            this.panel3.Controls.Add(this.lbTotalUsers);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(44, 108);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(427, 100);
            this.panel3.TabIndex = 8;
            // 
            // lbTotalUsers
            // 
            this.lbTotalUsers.AutoSize = true;
            this.lbTotalUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalUsers.ForeColor = System.Drawing.Color.White;
            this.lbTotalUsers.Location = new System.Drawing.Point(219, 52);
            this.lbTotalUsers.Name = "lbTotalUsers";
            this.lbTotalUsers.Size = new System.Drawing.Size(72, 37);
            this.lbTotalUsers.TabIndex = 6;
            this.lbTotalUsers.Text = "123";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(3, 13);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(114, 77);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(153, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(204, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Tổng số người dùng";
            // 
            // panelUsers
            // 
            this.panelUsers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panelUsers.Controls.Add(this.panel6);
            this.panelUsers.Controls.Add(this.panel5);
            this.panelUsers.Controls.Add(this.panel3);
            this.panelUsers.Controls.Add(this.label1);
            this.panelUsers.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUsers.Location = new System.Drawing.Point(0, 74);
            this.panelUsers.Name = "panelUsers";
            this.panelUsers.Size = new System.Drawing.Size(1932, 274);
            this.panelUsers.TabIndex = 9;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Olive;
            this.panel6.Controls.Add(this.lbTotalStudent);
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Location = new System.Drawing.Point(1173, 108);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(420, 100);
            this.panel6.TabIndex = 11;
            // 
            // lbTotalStudent
            // 
            this.lbTotalStudent.AutoSize = true;
            this.lbTotalStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalStudent.ForeColor = System.Drawing.Color.White;
            this.lbTotalStudent.Location = new System.Drawing.Point(219, 52);
            this.lbTotalStudent.Name = "lbTotalStudent";
            this.lbTotalStudent.Size = new System.Drawing.Size(72, 37);
            this.lbTotalStudent.TabIndex = 6;
            this.lbTotalStudent.Text = "123";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(3, 13);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(114, 77);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(192, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 25);
            this.label9.TabIndex = 5;
            this.label9.Text = "Sinh viên";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Olive;
            this.panel5.Controls.Add(this.lbTotalTeacher);
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Location = new System.Drawing.Point(614, 108);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(448, 100);
            this.panel5.TabIndex = 10;
            // 
            // lbTotalTeacher
            // 
            this.lbTotalTeacher.AutoSize = true;
            this.lbTotalTeacher.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalTeacher.ForeColor = System.Drawing.Color.White;
            this.lbTotalTeacher.Location = new System.Drawing.Point(248, 52);
            this.lbTotalTeacher.Name = "lbTotalTeacher";
            this.lbTotalTeacher.Size = new System.Drawing.Size(72, 37);
            this.lbTotalTeacher.TabIndex = 6;
            this.lbTotalTeacher.Text = "123";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(3, 13);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(114, 77);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(221, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 25);
            this.label7.TabIndex = 5;
            this.label7.Text = "Giảng Viên";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(54)))), ((int)(((byte)(226)))));
            this.panel4.Controls.Add(this.lbTotalBorrow);
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Location = new System.Drawing.Point(781, 95);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(357, 100);
            this.panel4.TabIndex = 9;
            // 
            // lbTotalBorrow
            // 
            this.lbTotalBorrow.AutoSize = true;
            this.lbTotalBorrow.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalBorrow.ForeColor = System.Drawing.Color.White;
            this.lbTotalBorrow.Location = new System.Drawing.Point(184, 50);
            this.lbTotalBorrow.Name = "lbTotalBorrow";
            this.lbTotalBorrow.Size = new System.Drawing.Size(72, 37);
            this.lbTotalBorrow.TabIndex = 6;
            this.lbTotalBorrow.Text = "123";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(3, 13);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(114, 77);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(116, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(214, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "Tổng lượt mượn sách";
            // 
            // panelEmployee
            // 
            this.panelEmployee.BackColor = System.Drawing.Color.White;
            this.panelEmployee.Controls.Add(this.panel10);
            this.panelEmployee.Controls.Add(this.panel9);
            this.panelEmployee.Controls.Add(this.panel8);
            this.panelEmployee.Controls.Add(this.panel7);
            this.panelEmployee.Controls.Add(this.label8);
            this.panelEmployee.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEmployee.Location = new System.Drawing.Point(0, 348);
            this.panelEmployee.Name = "panelEmployee";
            this.panelEmployee.Size = new System.Drawing.Size(1932, 213);
            this.panelEmployee.TabIndex = 10;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel10.Controls.Add(this.lbTotalArranger);
            this.panel10.Controls.Add(this.pictureBox10);
            this.panel10.Controls.Add(this.label12);
            this.panel10.Location = new System.Drawing.Point(1535, 91);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(352, 100);
            this.panel10.TabIndex = 15;
            // 
            // lbTotalArranger
            // 
            this.lbTotalArranger.AutoSize = true;
            this.lbTotalArranger.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalArranger.ForeColor = System.Drawing.Color.White;
            this.lbTotalArranger.Location = new System.Drawing.Point(201, 52);
            this.lbTotalArranger.Name = "lbTotalArranger";
            this.lbTotalArranger.Size = new System.Drawing.Size(72, 37);
            this.lbTotalArranger.TabIndex = 6;
            this.lbTotalArranger.Text = "123";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(3, 13);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(114, 77);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 5;
            this.pictureBox10.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(135, 13);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(144, 25);
            this.label12.TabIndex = 5;
            this.label12.Text = "Sắp xếp sách";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel9.Controls.Add(this.lbTotalDelivery);
            this.panel9.Controls.Add(this.pictureBox9);
            this.panel9.Controls.Add(this.label14);
            this.panel9.Location = new System.Drawing.Point(1067, 91);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(343, 100);
            this.panel9.TabIndex = 14;
            // 
            // lbTotalDelivery
            // 
            this.lbTotalDelivery.AutoSize = true;
            this.lbTotalDelivery.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalDelivery.ForeColor = System.Drawing.Color.White;
            this.lbTotalDelivery.Location = new System.Drawing.Point(201, 52);
            this.lbTotalDelivery.Name = "lbTotalDelivery";
            this.lbTotalDelivery.Size = new System.Drawing.Size(72, 37);
            this.lbTotalDelivery.TabIndex = 6;
            this.lbTotalDelivery.Text = "123";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(3, 13);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(114, 77);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 5;
            this.pictureBox9.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(135, 13);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(163, 25);
            this.label14.TabIndex = 5;
            this.label14.Text = "Trao nhận sách";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel8.Controls.Add(this.lbTotalManager);
            this.panel8.Controls.Add(this.pictureBox8);
            this.panel8.Controls.Add(this.lb10);
            this.panel8.Location = new System.Drawing.Point(614, 91);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(338, 100);
            this.panel8.TabIndex = 13;
            // 
            // lbTotalManager
            // 
            this.lbTotalManager.AutoSize = true;
            this.lbTotalManager.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalManager.ForeColor = System.Drawing.Color.White;
            this.lbTotalManager.Location = new System.Drawing.Point(177, 52);
            this.lbTotalManager.Name = "lbTotalManager";
            this.lbTotalManager.Size = new System.Drawing.Size(72, 37);
            this.lbTotalManager.TabIndex = 6;
            this.lbTotalManager.Text = "123";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(3, 13);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(114, 77);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 5;
            this.pictureBox8.TabStop = false;
            // 
            // lb10
            // 
            this.lb10.AutoSize = true;
            this.lb10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb10.ForeColor = System.Drawing.Color.White;
            this.lb10.Location = new System.Drawing.Point(162, 13);
            this.lb10.Name = "lb10";
            this.lb10.Size = new System.Drawing.Size(87, 25);
            this.lb10.TabIndex = 5;
            this.lb10.Text = "Quản lý";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel7.Controls.Add(this.lbTotalEmployee);
            this.panel7.Controls.Add(this.pictureBox7);
            this.panel7.Controls.Add(this.label11);
            this.panel7.Location = new System.Drawing.Point(50, 91);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(421, 100);
            this.panel7.TabIndex = 12;
            // 
            // lbTotalEmployee
            // 
            this.lbTotalEmployee.AutoSize = true;
            this.lbTotalEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalEmployee.ForeColor = System.Drawing.Color.White;
            this.lbTotalEmployee.Location = new System.Drawing.Point(219, 52);
            this.lbTotalEmployee.Name = "lbTotalEmployee";
            this.lbTotalEmployee.Size = new System.Drawing.Size(72, 37);
            this.lbTotalEmployee.TabIndex = 6;
            this.lbTotalEmployee.Text = "123";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(3, 13);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(114, 77);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 5;
            this.pictureBox7.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(153, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(191, 25);
            this.label11.TabIndex = 5;
            this.label11.Text = "Tổng số nhân viên";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(642, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(496, 40);
            this.label8.TabIndex = 11;
            this.label8.Text = "Thống kê nhân viên thư viện";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(642, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(411, 40);
            this.label3.TabIndex = 10;
            this.label3.Text = "Thống kê sách thư viện";
            // 
            // panelBooks
            // 
            this.panelBooks.Controls.Add(this.panel13);
            this.panelBooks.Controls.Add(this.panel12);
            this.panelBooks.Controls.Add(this.panel11);
            this.panelBooks.Controls.Add(this.label3);
            this.panelBooks.Controls.Add(this.panel2);
            this.panelBooks.Controls.Add(this.panel4);
            this.panelBooks.Controls.Add(this.panel1);
            this.panelBooks.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBooks.Location = new System.Drawing.Point(0, 561);
            this.panelBooks.Name = "panelBooks";
            this.panelBooks.Size = new System.Drawing.Size(1932, 469);
            this.panelBooks.TabIndex = 11;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel13.Controls.Add(this.lbBook5);
            this.panel13.Controls.Add(this.lbBook4);
            this.panel13.Controls.Add(this.lbBook3);
            this.panel13.Controls.Add(this.lbBook2);
            this.panel13.Controls.Add(this.lbBook1);
            this.panel13.Controls.Add(this.pictureBox13);
            this.panel13.Controls.Add(this.label15);
            this.panel13.Location = new System.Drawing.Point(208, 221);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(1589, 245);
            this.panel13.TabIndex = 12;
            // 
            // lbBook5
            // 
            this.lbBook5.AutoSize = true;
            this.lbBook5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBook5.ForeColor = System.Drawing.Color.White;
            this.lbBook5.Location = new System.Drawing.Point(740, 154);
            this.lbBook5.Name = "lbBook5";
            this.lbBook5.Size = new System.Drawing.Size(106, 37);
            this.lbBook5.TabIndex = 10;
            this.lbBook5.Text = "sach1";
            // 
            // lbBook4
            // 
            this.lbBook4.AutoSize = true;
            this.lbBook4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBook4.ForeColor = System.Drawing.Color.White;
            this.lbBook4.Location = new System.Drawing.Point(189, 154);
            this.lbBook4.Name = "lbBook4";
            this.lbBook4.Size = new System.Drawing.Size(106, 37);
            this.lbBook4.TabIndex = 9;
            this.lbBook4.Text = "sach1";
            // 
            // lbBook3
            // 
            this.lbBook3.AutoSize = true;
            this.lbBook3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBook3.ForeColor = System.Drawing.Color.White;
            this.lbBook3.Location = new System.Drawing.Point(911, 83);
            this.lbBook3.Name = "lbBook3";
            this.lbBook3.Size = new System.Drawing.Size(106, 37);
            this.lbBook3.TabIndex = 8;
            this.lbBook3.Text = "sach1";
            // 
            // lbBook2
            // 
            this.lbBook2.AutoSize = true;
            this.lbBook2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBook2.ForeColor = System.Drawing.Color.White;
            this.lbBook2.Location = new System.Drawing.Point(510, 83);
            this.lbBook2.Name = "lbBook2";
            this.lbBook2.Size = new System.Drawing.Size(106, 37);
            this.lbBook2.TabIndex = 7;
            this.lbBook2.Text = "sach1";
            // 
            // lbBook1
            // 
            this.lbBook1.AutoSize = true;
            this.lbBook1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBook1.ForeColor = System.Drawing.Color.White;
            this.lbBook1.Location = new System.Drawing.Point(33, 83);
            this.lbBook1.Name = "lbBook1";
            this.lbBook1.Size = new System.Drawing.Size(106, 37);
            this.lbBook1.TabIndex = 6;
            this.lbBook1.Text = "sach1";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(186, 3);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(109, 74);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 5;
            this.pictureBox13.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(310, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(528, 32);
            this.label15.TabIndex = 5;
            this.label15.Text = "Top 5 quyển sách được yêu thích nhất";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(54)))), ((int)(((byte)(226)))));
            this.panel12.Controls.Add(this.lbTotalBookReturned);
            this.panel12.Controls.Add(this.pictureBox12);
            this.panel12.Controls.Add(this.label16);
            this.panel12.Location = new System.Drawing.Point(1572, 95);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(315, 100);
            this.panel12.TabIndex = 11;
            // 
            // lbTotalBookReturned
            // 
            this.lbTotalBookReturned.AutoSize = true;
            this.lbTotalBookReturned.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalBookReturned.ForeColor = System.Drawing.Color.White;
            this.lbTotalBookReturned.Location = new System.Drawing.Point(177, 50);
            this.lbTotalBookReturned.Name = "lbTotalBookReturned";
            this.lbTotalBookReturned.Size = new System.Drawing.Size(72, 37);
            this.lbTotalBookReturned.TabIndex = 6;
            this.lbTotalBookReturned.Text = "123";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(3, 13);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(114, 77);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 5;
            this.pictureBox12.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(123, 11);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(115, 25);
            this.label16.TabIndex = 5;
            this.label16.Text = "Lượt đã trả";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(54)))), ((int)(((byte)(226)))));
            this.panel11.Controls.Add(this.lbTotalBorrowing);
            this.panel11.Controls.Add(this.pictureBox11);
            this.panel11.Controls.Add(this.label13);
            this.panel11.Location = new System.Drawing.Point(1176, 95);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(332, 100);
            this.panel11.TabIndex = 10;
            // 
            // lbTotalBorrowing
            // 
            this.lbTotalBorrowing.AutoSize = true;
            this.lbTotalBorrowing.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTotalBorrowing.ForeColor = System.Drawing.Color.White;
            this.lbTotalBorrowing.Location = new System.Drawing.Point(177, 50);
            this.lbTotalBorrowing.Name = "lbTotalBorrowing";
            this.lbTotalBorrowing.Size = new System.Drawing.Size(72, 37);
            this.lbTotalBorrowing.TabIndex = 6;
            this.lbTotalBorrowing.Text = "123";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(3, 13);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(114, 77);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 5;
            this.pictureBox11.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(123, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(167, 25);
            this.label13.TabIndex = 5;
            this.label13.Text = "Lượt đang mượn";
            // 
            // panelFooter
            // 
            this.panelFooter.Controls.Add(this.lbFooter);
            this.panelFooter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelFooter.Location = new System.Drawing.Point(0, 1038);
            this.panelFooter.Name = "panelFooter";
            this.panelFooter.Size = new System.Drawing.Size(1932, 68);
            this.panelFooter.TabIndex = 12;
            // 
            // lbFooter
            // 
            this.lbFooter.AutoSize = true;
            this.lbFooter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFooter.Location = new System.Drawing.Point(471, 32);
            this.lbFooter.Name = "lbFooter";
            this.lbFooter.Size = new System.Drawing.Size(770, 25);
            this.lbFooter.TabIndex = 0;
            this.lbFooter.Text = "© 2021 HCMUTE, Thư Viện Trường Đại Học Sư phạm kỹ thuật TP.Hồ Chí Minh";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.Red;
            this.btnClose.Location = new System.Drawing.Point(1872, 14);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(39, 45);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "X";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnMinimize
            // 
            this.btnMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMinimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimize.ForeColor = System.Drawing.Color.Red;
            this.btnMinimize.Location = new System.Drawing.Point(1814, 14);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(41, 45);
            this.btnMinimize.TabIndex = 14;
            this.btnMinimize.Text = "-";
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // DashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1932, 1106);
            this.Controls.Add(this.btnMinimize);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.panelFooter);
            this.Controls.Add(this.panelBooks);
            this.Controls.Add(this.panelEmployee);
            this.Controls.Add(this.panelUsers);
            this.Controls.Add(this.lbUsername);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "DashboardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashboardForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.DashboardForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panelUsers.ResumeLayout(false);
            this.panelUsers.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panelEmployee.ResumeLayout(false);
            this.panelEmployee.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panelBooks.ResumeLayout(false);
            this.panelBooks.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.panelFooter.ResumeLayout(false);
            this.panelFooter.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem booksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewBookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem issueBooksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewBookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label lbUsername;
        private System.Windows.Forms.ToolStripMenuItem bookTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem myAccountToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbTotalCategories;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbTotalBooks;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbTotalUsers;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panelUsers;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbTotalBorrow;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panelEmployee;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbTotalTeacher;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbTotalStudent;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panelBooks;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lbTotalEmployee;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lbTotalDelivery;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lbTotalManager;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label lb10;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label lbTotalArranger;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label lbTotalBorrowing;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label lbTotalBookReturned;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label lbBook1;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lbBook3;
        private System.Windows.Forms.Label lbBook2;
        private System.Windows.Forms.Label lbBook5;
        private System.Windows.Forms.Label lbBook4;
        private System.Windows.Forms.Panel panelFooter;
        private System.Windows.Forms.Label lbFooter;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.ToolStripMenuItem lendsBookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lendBookToLibraryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem myListBookToolStripMenuItem;
    }
}