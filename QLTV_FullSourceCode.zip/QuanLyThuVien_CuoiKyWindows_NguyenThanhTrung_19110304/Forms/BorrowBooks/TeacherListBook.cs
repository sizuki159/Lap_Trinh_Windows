﻿using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.BorrowBooks
{
    public partial class TeacherListBook : Form
    {
        public static Database database = new Database();
        public string UserCode = Classes.Users.InfoUserLogin["code"].ToString();

        public TeacherListBook()
        {
            InitializeComponent();
        }
        static int bookID = -1;

        private void dataGridViewListInfoBook_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewListInfoBook.CurrentRow.Cells[0].Value != null)
                bookID = int.Parse(dataGridViewListInfoBook.CurrentRow.Cells[0].Value.ToString());
            else
            {
                MessageBox.Show("Lỗi không convert được ID sách", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            panelInfoBook.Visible = true;
            DataTable infoBook = Classes.Borrows.getInfoOneBookBorrowing2(bookID.ToString());
            txbName.Text = infoBook.Rows[0]["bookname"].ToString();
            txbAuthorName.Text = infoBook.Rows[0]["authorname"].ToString();
            nrudPrice.Value = int.Parse(infoBook.Rows[0]["price"].ToString());
            nrudQuantity.Value = int.Parse(infoBook.Rows[0]["quantity"].ToString());
            rtbDescription.Text = infoBook.Rows[0]["description"].ToString();
            try
            {
                Byte[] dataImage = new Byte[0];
                dataImage = (Byte[])(infoBook.Rows[0]["images"]);
                MemoryStream mem = new MemoryStream(dataImage);
                pictureBoxBookPreview.Image = Image.FromStream(mem);
            }
            catch
            {
                pictureBoxBookPreview.Image = null;
            }


        }

        private void TeacherListBook_Load(object sender, EventArgs e)
        {
            panelInfoBook.Visible = false;
            Classes.TrungHelper.setDefaultDataGridView(dataGridViewListInfoBook, Classes.Borrows.getListBookLending(UserCode));

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            try
            {
                bool isDeleted = Classes.Borrows.removeTeacherBook(bookID.ToString());

                if (isDeleted)
                {
                    MessageBox.Show("GetBack Books Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridViewListInfoBook.DataSource = Classes.Borrows.getListBookLending(UserCode);
                    panelInfoBook.Visible = false;
                }
                else
                {
                    MessageBox.Show("GetBack Books Fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void txbBookName_TextChanged(object sender, EventArgs e)
        {
            string search = string.Format("%{0}%", txbBookName.Text);
            dataGridViewListInfoBook.DataSource = Classes.Borrows.getListBookLending(UserCode, search);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txbBookName.Text = string.Empty;
        }
    }
}
