﻿using QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyThuVien_CuoiKyWindows_NguyenThanhTrung_19110304.Forms.BorrowBooks
{
    public partial class TeacherAddBooks : Form
    {
        public static Database database = new Database();
        public string UserCode = Classes.Users.InfoUserLogin["code"].ToString();
        public TeacherAddBooks()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Classes.Books book = new Classes.Books();
                book.Name = txbName.Text;
                book.AuthorName = txbAuthorName.Text;

                Classes.Books.Book_Type booktype = comboBoxType.SelectedItem as Classes.Books.Book_Type;
                if (booktype == null)
                {
                    MessageBox.Show("Please Choose Book Type", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                book.BookType = int.Parse(booktype.ID);
                book.Price = (float)nrudPrice.Value;
                book.Quantity = (int)nrudQuantity.Value;
                book.Description = rtbDescription.Text;


                book.Image = pictureBoxBookPreview.Image;

                if (ValidateForm("add"))
                    if (book.isInsert2(UserCode))
                        MessageBox.Show("Lend Book Success", "Action Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Add Book Fail", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("Data input errors", "Action Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception Errors", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateForm(string operation)
        {
            if (operation == "add")
            {
                if (string.IsNullOrEmpty(txbName.Text) || string.IsNullOrEmpty(txbAuthorName.Text)
                                        || string.IsNullOrEmpty(rtbDescription.Text))
                    return false;
                return true;
            }
            return false;
        }

        private void pictureBoxUploadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.png; *.jpeg; *.gif; *.bmp)|*.jpg; *.png; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                pictureBoxBookPreview.Image = new Bitmap(open.FileName);
            }
        }

        private void TeacherAddBooks_Load(object sender, EventArgs e)
        {
            Classes.Books.loadComboBoxBookType(comboBoxType);
        }
    }
}
